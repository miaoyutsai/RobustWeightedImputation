# file name: Application_study_1SMVL.R: robust one-stage imputation approach under MVSOM with the detection of outliers using the proposed LRT
###############################################################################################################################
#########################################       R code for the myopia twin study       ########################################      
###############################################################################################################################
## Please implement the Application_ConditionalCookD.R

source("D:\\Application_Allfunctions.R")

load("D:\\Application_proposedLRT.RData")

library(MASS);library(Matrix);library(nlme);library(mice);library(cccrm);library(doBy)
set.seed(30)

twinMDZ<-read.csv(file="d:\\twin.csv",header=T,na.strings = ".")
twinMZ<-subset(twinMDZ,MDZZ==1)
twinMZsort<-orderBy(~NO+twin1+loc,twinMZ)
winMZsort<-orderBy(~NO+twin1+loc,twinMZ)

M=1
n=40       
nm=2       
nt=2      
nL=2
DW=DW.matrix(nt,0)

  x0<-rep(1,n*nm*nt*nL)
  x1<-rep(rep(c(0,0,1,1),each=nL),n)
  x2<-rep(rep(c(0,1,0,1),each=nL),n)
  x3<-rep(rep(c(0,0,0,1),each=nL),n)

#The settings of parameters for missingness models
b1=-2.6
b2=0.08
b3=0.2
b4=-2.7
b5=0.08
b6=0.2

alldata<-twinMZsort

 #define Z 
  ai<-rep(1,nm*nt*nL)
  abi1<-rep(c(1,1,0,0),each=nL)
  abi2<-rep(c(0,0,1,1),each=nL)
  ari1<-rep(c(1,0,1,0),each=nL)
  ari2<-rep(c(0,1,0,1),each=nL)
  z<-cbind(ai,abi1,abi2,ari1,ari2)
  Z<-kronecker(diag(n),z)

prob_mis<-array(0,dim=c(n*nm*nt*nL,3,M)) 
orgin<-array(0,dim=c(n*nm*nt*nL,3,M))
colnames(orgin)<-c("y","x7","x6")
mis_number<-matrix(0,nrow=2,ncol=M) 

# parameters for the x7 model 
bi.x_record<-array(0,dim=c(2*n,5,M))
beta.x_record<-array(0,dim=c(3,5,M))
sigma.x_record<-array(0,dim=c(3,5,M))
x7_record<-array(0,dim=c(n*nm*nt*nL,5,M))

# parameters for the y model 
bi_record<-array(0,dim=c(ncol(z)*n,5,M))
beta_record<-array(0,dim=c(6,5,M))
sigma_record<-array(0,dim=c(4,5,M))
y_record<-array(0,dim=c(n*nm*nt*nL,5,M))

mis_Y<-mis_x7<-matrix(0,nrow=M,ncol=n*nm*nt*nL)

 ind=rep(1:n,each=(nm*nt*nL))
 method<-rep(1:nm,each=nt*nL,times=n)-1
 time<-rep(rep(1:nt,each=nL),times=(n*nm))
 repl<-rep(1:(nm*nt*nL),n)

for (r in (1:M)){
  xy_data<-as.data.frame(alldata)            
  x6<-xy_data$P
  prob_mis[,1,r]<-x6
  orgin[,3,r]<-x6
  y<-xy_data$y      
  orgin[,1,r]<-y
  mis_Y[r,]<-y         
  x7<-xy_data$AL    
  orgin[,2,r]<-x7
  mis_x7[r,]<-x7       
    
#Creating missing values
  for(i in (1:(n*nm*nt*nL))){
    ey<-exp(b1+b2*x6[i]+b3*method[i])
    ex<-exp(b4+b5*x6[i]+b6*y[i])
    p_y<-ey/(1+ey)
    p_x<-ex/(1+ex)
    prob_mis[i,2,r]<-p_y
    prob_mis[i,3,r]<-p_x
    my<-sample(c(1:2),1,prob=c(p_y,1-p_y))
    mx<-sample(c(1:2),1,prob=c(p_x,1-p_x))
    if(my==1&i%in%c(1:(n*nm*nt*nL))[-c(97:104,249:256)]){
      mis_Y[r,i]<-NA
    }
    if(mx==1&i%in%c(1:(n*nm*nt*nL))[-c(97:104,249:256)]){
      mis_x7[r,i]<-NA
    }
  }
}

alldatanew=alldata

LMMest.com<-LMMestnew.com<-matrix(0,M,19)
vcest.com<-vcestnew.com<-matrix(0,M,5)
LMMest.obs<-LMMestnew.obs<-matrix(0,M,19)
vcest.obs<-vcestnew.obs<-matrix(0,M,5)

for (r in (1:M)){ 
  mis_number[1,r]<-length(which(is.na(mis_Y[r,])))
  mis_number[2,r]<-length(which(is.na(mis_x7[r,])))
  misY_obs<-which(is.na(mis_Y[r,]))
  misX_obs<-which(is.na(mis_x7[r,]))
  misXY_obs<-sort(union(misY_obs,misX_obs))
  mis_personY<-unique(ceiling(misY_obs/(nm*nt*nL)))
  mis_personX<-unique(ceiling(misX_obs/(nm*nt*nL)))
   
  y.old<-alldata[,4]           
  y<-y.old
  y[c(97:104)]=y[c(97:104)]-0.5
  y[c(249:256)]=y[c(249:256)]+2
  alldatanew[,4]=y
  
  xy_data<-as.data.frame(alldatanew)            
  y<-xy_data$y    
  x6<-xy_data$P  
  x7<-xy_data$AL 
 
  com_data<-as.data.frame(cbind(y,ind,method,time,x6,x7,repl))
  colnames(com_data)<-c("y","ind","method","time","x6","x7","rep")
  com_data$y<-as.numeric(com_data$y)
  com_data$ind<-as.factor(com_data$ind)
  com_data$method<-as.factor(com_data$method)
  com_data$time<-as.factor(com_data$time)
  com_data$x6<-as.numeric(com_data$x6)
  com_data$x7<-as.numeric(com_data$x7)
  
  form=y~method+time+method*time+x6+x7
  model_complete<-lme(form,data=com_data,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time)))))

  vc1<-exp(2*attr(model_complete$apVar,'Pars'))
  if(length(vc1)<1){
    r<-r+1
    next
  }

cccrm.com=ccclonw.default(com_data,"y","ind","time","method",D=DW,covar=c("x6","x7"),rho=0,nL)
LMMest.com[r,]=c((cccrm.com)$ccc.i,(cccrm.com)$nonpd)
vcest.com[r,]=c((cccrm.com)$vc)
 
  obs_data<-com_data[-misXY_obs,]
  colnames(obs_data)<-c("y","ind","method","time","x6","x7","rep")
  obs_data$y<-as.numeric(obs_data$y)
  obs_data$ind<-as.factor(obs_data$ind)
  obs_data$method<-as.factor(obs_data$method)
  obs_data$time<-as.factor(obs_data$time)
  obs_data$x6<-as.numeric(obs_data$x6)
  obs_data$x7<-as.numeric(obs_data$x7)
  
  form=y~method+time+method*time+x6+x7
  model_obsXY<-lme(form,data=obs_data,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time)))))  
  
  vc2<-exp(2*attr(model_obsXY$apVar,'Pars'))
  if(length(vc2)<1){
    r<-r+1
    next
  } 
  beta.obs<-summary(model_obsXY)$tTable[,1]

cccrm.obs=ccclonw.default.obs(obs_data,"y","ind","time","method",D=DW,covar=c("x6","x7"),rho=0,nL)
LMMest.obs[r,]=c((cccrm.obs)$ccc.i,(cccrm.obs)$nonpd)
vcest.obs[r,]=c((cccrm.obs)$vc)

d=rep(0,n*nm*nt*nL)
detect.outlier=which(outlier.select[,r]==1)

  for (jj in 1:5){
  y<-xy_data$y    
  x6<-xy_data$P  
  x7<-xy_data$AL  
   
  xymis_data<-cbind(com_data,d)[-misXY_obs,]
  colnames(xymis_data)<-c("y","ind","method","time","x6","x7","rep","d")
  xymis_data$y<-as.numeric(xymis_data$y)
  xymis_data$ind<-as.factor(xymis_data$ind)
  xymis_data$method<-as.factor(xymis_data$method)
  xymis_data$time<-as.factor(xymis_data$time)
  xymis_data$x6<-as.numeric(xymis_data$x6)
  xymis_data$x7<-as.numeric(xymis_data$x7)

model.x=NULL
tryCatch({model.x=lme(x7~x6+y,data=xymis_data,random=list(ind=pdDiag(form=~x6)))}, error=function(e){})

if(length(model.x)==0|is.character(model.x$apVar)==TRUE){
#stop("Non-positive definite approximate variance-covariance")
beta.x_record[,jj,r]<-0
sigma.x_record[,jj,r]<-0
bi.x_record[,jj,r]<-0
x7_record[,jj,r]<-0
}

if(length(model.x)!=0&is.character(model.x$apVar)==FALSE){
  b.x<-as.matrix(model.x$coef$fixed)
  Sb.x<-as.matrix(model.x$varFix)
  logvc.x<-as.matrix(attr(model.x$apVar,'Pars'))
  Slogvc.x<-model.x$apVar[1:3,1:3]

   beta.x_record[,jj,r]<-mvrnorm(1,b.x,Sb.x)
   sigma.x_record[,jj,r]<-exp(2*mvrnorm(1,logvc.x,Slogvc.x))

    X.x<-cbind(rep(1,n*nm*nt*nL),x6,y)
    Z.x<-cbind(rep(1,n*nm*nt*nL),x6)
    bi.x<-rep(0,n*2)

    for(ri in (1:n)){
     misxy=which(misXY_obs>=(nm*nt*nL*(ri-1)+1)&misXY_obs<=(nm*nt*nL*(ri)))
     mis.xy=which(c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))%in%misXY_obs[misxy])
     if (length(misxy)==0){X.xi<-X.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri)),];
                          Z.xi<-Z.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri)),];
                          x7.xx=x7[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))];
     GG.x<-ginv(t(Z.xi)%*%ginv(diag(sigma.x_record[3,jj,r],nm*nt*nL-length(mis.xy),nm*nt*nL-length(mis.xy)))%*%Z.xi+
           ginv(diag(sigma.x_record[1:2,jj,r])));
     bi.x[((ri-1)*2+1):(ri*2)]<-mvrnorm(1,diag(sigma.x_record[1:2,jj,r])%*%t(Z.xi)%*%ginv(Z.xi%*%diag(sigma.x_record[1:2,jj,r])%*%t(Z.xi)+
                                diag(sigma.x_record[3,jj,r],nm*nt*nL-length(mis.xy),nm*nt*nL-length(mis.xy)))%*%
                                (x7.xx-X.xi%*%beta.x_record[,jj,r]),GG.x)}

     if (length(misxy)>0){X.xi<-matrix(X.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.xy],],ncol=ncol(X.x));
                          Z.xi<-matrix(Z.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.xy],],ncol=ncol(Z.x));
                          x7.xx=x7[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.xy]]}
     
     if (length(misxy)>0 & length(misxy)<(nm*nt*nL)){  
     GG.x<-ginv(t(Z.xi)%*%ginv(diag(sigma.x_record[3,jj,r],nm*nt*nL-length(mis.xy),nm*nt*nL-length(mis.xy)))%*%Z.xi+
           ginv(diag(sigma.x_record[1:2,jj,r])));
     bi.x[((ri-1)*2+1):(ri*2)]<-mvrnorm(1,diag(sigma.x_record[1:2,jj,r])%*%t(Z.xi)%*%ginv(Z.xi%*%diag(sigma.x_record[1:2,jj,r])%*%t(Z.xi)+
                                diag(sigma.x_record[3,jj,r],nm*nt*nL-length(mis.xy),nm*nt*nL-length(mis.xy)))%*%
                                (x7.xx-X.xi%*%beta.x_record[,jj,r]), GG.x)}  

     if (length(misxy)==nm*nt*nL){bi.x[((ri-1)*2+1):(ri*2)]<-mvrnorm(1,rep(0,2),diag(sigma.x_record[1:2,jj,r]))}  
            
     if(ri %in% mis_personX){
        e.x<-mvrnorm(1,rep(0,nm*nt*nL),diag(sigma.x_record[3,jj,r],nm*nt*nL,nm*nt*nL))
        Xmis<-X.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri)),]%*%beta.x_record[,jj,r]+Z.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri)),]%*%bi.x[((ri-1)*2+1):(ri*2)]+e.x  
        for(j in (1:(nm*nt*nL))){
          if(is.na(mis_x7[r,(ri-1)*nm*nt*nL+j])){
            x7[(ri-1)*nm*nt*nL+j]<-Xmis[j]
          }
        }
      }
    }
    bi.x_record[,jj,r]<-bi.x
    x7_record[,jj,r]<-x7
 
  X<-cbind(x0,x1,x2,xy_data$P,x7,x3) }     
 
if (length(detect.outlier)>0){
for (dd in 1:length(detect.outlier)){d[((detect.outlier[dd]-1)*(nm*nt*nL)+1):((detect.outlier[dd])*(nm*nt*nL))]=1}
 
  ymis_data<-cbind(com_data,d)[-misXY_obs,]
  colnames(ymis_data)<-c("y","ind","method","time","x6","x7","rep","d")
  ymis_data$y<-as.numeric(ymis_data$y)
  ymis_data$ind<-as.factor(ymis_data$ind)
  ymis_data$method<-as.factor(ymis_data$method)
  ymis_data$time<-as.factor(ymis_data$time)
  ymis_data$x6<-as.numeric(ymis_data$x6)
  ymis_data$x7<-as.numeric(ymis_data$x7)
    
model.y=NULL
tryCatch({model.y<-lme(y~method+time+method*time+x6+x7+d,data=ymis_data,random=list(ind=pdBlocked(list(pdIdent(form=~1+d),pdIdent(form=~-1+method),pdIdent(form=~-1+time))))) }, 
error=function(e){})  

if(length(model.x)!=0&is.character(model.x$apVar)==FALSE&length(model.y)!=0&is.character(model.y$apVar)==FALSE){

 b.y<-as.matrix(model.y$coef$fixed)[-7,1]
 Sb.y<-as.matrix(model.y$varFix)[-7,-7]
 logvc.y<-as.matrix(attr(model.y$apVar,'Pars'))
 Slogvc.y<-model.y$apVar

 beta_record[,jj,r]<-mvrnorm(1,b.y,Sb.y)
 sigma_record[,jj,r]<-exp(2*mvrnorm(1,logvc.y,Slogvc.y))

    bi.y<-rep(0,n*(1+nm+nt))
    for(ri in (1:n)){
     misy=which(misY_obs>=(nm*nt*nL*(ri-1)+1)&misY_obs<=(nm*nt*nL*(ri)))
     mis.y=which(c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))%in%misY_obs[misy])

     if (length(misy)==0){X.y=X[(nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri),];y.y=y[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))];z.y=z;
     GG.y<-ginv(t(z)%*%ginv(diag(sigma_record[4,jj,r],nm*nt*nL,nm*nt*nL))%*%z+
           ginv(diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))));
     bi.y.mean<-diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)%*%
          ginv(z.y%*%diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)+
          diag(sigma_record[4,jj,r],nm*nt*nL-length(mis.y),nm*nt*nL-length(mis.y)))%*%(y.y-X.y%*%beta_record[,jj,r]);
     bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]<-mvrnorm(1,bi.y.mean, GG.y)}

     if (length(misy)>0){X.y=matrix(X[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.y],],ncol=ncol(X));y.y=y[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.y]];z.y=matrix(z[-mis.y,],ncol=ncol(z))}
     
     if (length(misy)>0 & length(misy)<(nm*nt*nL)){  
     GG.y<-ginv(t(z.y)%*%ginv(diag(sigma_record[4,jj,r],nm*nt*nL-length(mis.y),nm*nt*nL-length(mis.y)))%*%z.y+
           ginv(diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))));   
     bi.y.mean<-diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)%*%
                 ginv(z.y%*%diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)+
                 diag(sigma_record[4,jj,r],nm*nt*nL-length(mis.y),nm*nt*nL-length(mis.y)))%*%(y.y-X.y%*%beta_record[,jj,r]);
     bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]<-mvrnorm(1,bi.y.mean, GG.y) }  
 
     if (length(misy)==nm*nt*nL){bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]<-mvrnorm(1,rep(0,(1+nm+nt)),diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))) } 
   
     if(ri %in% mis_personY){
        e<-mvrnorm(1,rep(0,nm*nt*nL),diag(sigma_record[4,jj,r],nm*nt*nL,nm*nt*nL))
        Ymis<-X[(nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri),]%*%beta_record[,jj,r]+z%*%bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]+e
        for(j in (1:(nm*nt*nL))){
          if(is.na(mis_Y[r,(nm*nt*nL*(ri-1)+j)])){
          y[(nm*nt*nL*(ri-1)+j)]<-Ymis[j]
          }
        }
      }
    }
    bi_record[,jj,r]<-bi.y 
    y_record[,jj,r]<-y
    } }  

if (length(detect.outlier)==0){

  ymis_data<-cbind(com_data,d)[-misXY_obs,]
  colnames(ymis_data)<-c("y","ind","method","time","x6","x7","rep","d")
  ymis_data$y<-as.numeric(ymis_data$y)
  ymis_data$ind<-as.factor(ymis_data$ind)
  ymis_data$method<-as.factor(ymis_data$method)
  ymis_data$time<-as.factor(ymis_data$time)
  ymis_data$x6<-as.numeric(ymis_data$x6)
  ymis_data$x7<-as.numeric(ymis_data$x7)
    
model.y=NULL
tryCatch({model.y<-lme(y~method+time+method*time+x6+x7,data=ymis_data,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time))))) }, 
error=function(e){})
 
if(length(model.x)!=0&is.character(model.x$apVar)==FALSE&length(model.y)!=0&is.character(model.y$apVar)==FALSE){

 b.y<-as.matrix(model.y$coef$fixed)
 Sb.y<-as.matrix(model.y$varFix)
 logvc.y<-as.matrix(attr(model.y$apVar,'Pars'))
 Slogvc.y<-model.y$apVar[1:4,1:4]

 beta_record[,jj,r]<-mvrnorm(1,b.y,Sb.y)
 sigma_record[,jj,r]<-exp(2*mvrnorm(1,logvc.y,Slogvc.y))

    bi.y<-rep(0,n*(1+nm+nt))
    for(ri in (1:n)){
     misy=which(misY_obs>=(nm*nt*nL*(ri-1)+1)&misY_obs<=(nm*nt*nL*(ri)))
     mis.y=which(c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))%in%misY_obs[misy])

     if (length(misy)==0){X.y=X[(nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri),];y.y=y[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))];z.y=z;
     GG.y<-ginv(t(z)%*%ginv(diag(sigma_record[4,jj,r],nm*nt*nL,nm*nt*nL))%*%z+
           ginv(diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))));
     bi.y.mean<-diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)%*%
          ginv(z.y%*%diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)+
          diag(sigma_record[4,jj,r],nm*nt*nL-length(mis.y),nm*nt*nL-length(mis.y)))%*%(y.y-X.y%*%beta_record[,jj,r]);
     bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]<-mvrnorm(1,bi.y.mean, GG.y)}

     if (length(misy)>0){X.y=matrix(X[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.y],],ncol=ncol(X));y.y=y[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.y]];z.y=matrix(z[-mis.y,],ncol=ncol(z))}
     
     if (length(misy)>0 & length(misy)<(nm*nt*nL)){  
     GG.y<-ginv(t(z.y)%*%ginv(diag(sigma_record[4,jj,r],nm*nt*nL-length(mis.y),nm*nt*nL-length(mis.y)))%*%z.y+
           ginv(diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))));   
     bi.y.mean<-diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)%*%
                 ginv(z.y%*%diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)+
                 diag(sigma_record[4,jj,r],nm*nt*nL-length(mis.y),nm*nt*nL-length(mis.y)))%*%(y.y-X.y%*%beta_record[,jj,r]);
     bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]<-mvrnorm(1,bi.y.mean, GG.y) }  
 
     if (length(misy)==nm*nt*nL){bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]<-mvrnorm(1,rep(0,(1+nm+nt)),diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))) } 
   
     if(ri %in% mis_personY){
        e<-mvrnorm(1,rep(0,nm*nt*nL),diag(sigma_record[4,jj,r],nm*nt*nL,nm*nt*nL))
        Ymis<-X[(nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri),]%*%beta_record[,jj,r]+z%*%bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]+e
        for(j in (1:(nm*nt*nL))){
          if(is.na(mis_Y[r,(nm*nt*nL*(ri-1)+j)])){
          y[(nm*nt*nL*(ri-1)+j)]<-Ymis[j]
          }
        }
      }
    }
    bi_record[,jj,r]<-bi.y 
    y_record[,jj,r]<-y
    } } 

if(length(model.x)==0|is.character(model.x$apVar)==TRUE|length(model.y)==0|is.character(model.y$apVar)==TRUE){
#stop("Non-positive definite approximate variance-covariance")
beta_record[,jj,r]<-0
sigma_record[,jj,r]<-0
bi_record[,jj,r]<-0
y_record[,jj,r]<-0
} }
}


LMMest<-LMMestnew<-array(0,dim=c(5,19,M))
vcest<-array(0,dim=c(5,5,M))
noimpute<-rep(1,M)

for(r in (1:M)){
  if(sum(y_record[,1,r])==0){
   noimpute[r]=ifelse(sum(y_record[,1,r])==0,0,1)
    r<-r+1
    next
  }
  xy_data<-as.data.frame(alldata[,,r]) 

  for(i in 1:5){
  y<-y_record[,i,r]
  x7<-x7_record[,i,r]
  dataset=data.frame(y,ind,method,time,xy_data$P,x7)
  colnames(dataset)<-c("y","ind","method","time","P","x7")
cccrm.est=ccclonw.default(dataset,"y","ind","time","method",D=DW,covar=c("P","x7"),rho=0,nL)

LMMest[i,,r]=c((cccrm.est)$ccc.i,(cccrm.est)$nonpd)
vcest[i,,r]=c((cccrm.est)$vc)
}
}

MM=ifelse(length(which(noimpute==0))>0, M-length(which(noimpute==0)), M)
LMMestnew=LMMest
vcestnew=vcest

if(length(which(noimpute==0))>0) {
LMMestnew=LMMest[,,-which(noimpute==0)]
vcestnew=vcest[,,-which(noimpute==0)]
}

rho_post<-matrix(0,MM,ncol(LMMestnew))
rho_post_var<-matrix(0,MM,3)

#rubin's rule
for (r in (1:MM)){

  nocon<-which(apply(LMMestnew[,,r],1,sum)==1) 
  nocon_number<-length(nocon) 
  
  m=5-nocon_number
 
if (nocon_number>0&nocon_number<4)  {rho_mean<-apply(LMMestnew[-nocon,,r],2,mean); Vw<-apply(as.matrix(LMMestnew[-nocon,c(4,10,16),r]^2),2,mean) }
if (nocon_number==4)  {rho_mean<-LMMestnew[-nocon,,r]; Vw<-as.matrix(LMMestnew[-nocon,c(4,10,16),r]^2) }
if (nocon_number==0)  {rho_mean<-apply(LMMestnew[,,r],2,mean); Vw<-apply(as.matrix(LMMestnew[,c(4,10,16),r]^2),2,mean) }

if (nocon_number>0&nocon_number<4)  { Vb<-apply(as.matrix(LMMestnew[-nocon,c(1,7,13),r]-matrix(rep(rho_mean[c(1,7,13)],m),nrow=m,ncol=3,byrow=T))^2,2,sum)/(m-1) }
if (nocon_number==4)  { Vb<-0 }
if (nocon_number==0)  { Vb<-apply(as.matrix(LMMestnew[,c(1,7,13),r]-matrix(rep(rho_mean[c(1,7,13)],m),nrow=m,ncol=3,byrow=T))^2,2,sum)/(m-1) }

Vt<-Vw+(1+1/m)*Vb  
  
  rho_post[r,]<-rho_mean
  rho_post_var[r,]<-Vt
 }


############## CI ##################
CCC.CI=function(ccc,se.ccc){
z<-0.5*log((1+ccc)/(1-ccc))
se.z<-sqrt(  (se.ccc^2)/(((1+ccc)^2)*((1-ccc)^2))  )
ll.z<-z-qnorm(0.975)*se.z
ul.z<-z+qnorm(0.975)*se.z
ll95<- (exp(2*ll.z)-1)/(exp(2*ll.z)+1)
ul95<- (exp(2*ul.z)-1)/(exp(2*ul.z)+1)
return(c(ll95,ul95))
}

cccrm.hat=rho_post[c(1,7,13)]
CI<-matrix(0,3,2)
for (i in 1:length(cccrm.hat)){
CI[i,]=CCC.CI(cccrm.hat[i],rho_post_var[i]^0.5)
}

round(cccrm.hat,4)
round(CI,4)
apply(round(CI,4),1,diff)



