# file name: Application_Allfunctions.R: All functions for the appliction
##############################################################################################################################################################
#########################################       R code for the myopia twin study      ########################################      
##############################################################################################################################################################

boots_data_frame<-function(n,nm,nt,nL,beta.hat,sa.hat,sab.hat,sag.hat,se.hat,X.com,Bnum){
  #generate Z as design matrix 
  ai<-rep(1,nm*nt*nL)
  abi1<-rep(c(1,1,0,0),each=nL)
  abi2<-rep(c(0,0,1,1),each=nL)
  ari1<-rep(c(1,0,1,0),each=nL)
  ari2<-rep(c(0,1,0,1),each=nL)
  z<-cbind(ai,abi1,abi2,ari1,ari2)
  Z<-kronecker(diag(n),z)

    #generate b as randon effects
    #G is a variance-covariance matrix of random effects
    G<-diag(c(sa.hat,rep(sab.hat,nm),rep(sag.hat,nt)))
    bi=c(t(mvrnorm(n,rep(0,(1+nm+nt)),G,empirical = F)))   #generate random-effects vectors
     
    #generate random error 
    R<-diag(se.hat,nrow=nm*nt*nL,ncol=nm*nt*nL)
    e<-c(t(mvrnorm(n,rep(0,nm*nt*nL),R,empirical = F)))
   
    #combine Y
    y.star<-X.com%*%beta.hat+Z%*%bi+e
return(y.star)
}



#################### the VC approach under LMM #################### 
ccclonw.default<-function(dataset,y,ind,method,time,D,covar,rho,nL){
dataset$ind<-as.factor(dataset$ind)
dataset$method<-as.factor(dataset$method)
dataset$time<-as.factor(dataset$time)
dataset$y<-as.numeric(dataset$y)

form=y~method+time+method*time
if (length(covar)>0){
new.covar <- covar[1]
for(ii in c(2:length(covar))){ new.covar <- paste(new.covar, covar[ii], sep="+") }
form<-as.formula(paste("y~method+time+method*time",new.covar,sep="+"))}

model.lme=NULL
#Coumpund simmetry model
tryCatch({model.lme<-lme(form,dataset,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time)))))  }, error=function(e){})

if(length(model.lme)==0|is.character(model.lme$apVar)==TRUE){
#stop("Non-positive definite approximate variance-covariance")
res<-list(ccc.p=NULL,ccc.i=rep(0,18),vc=rep(0,5),sigma=NULL,model=NULL,nonpd=1)
class(res)<-"ccclonw"
res}

if(length(model.lme)!=0&is.character(model.lme$apVar)==FALSE){
nonpd=0

model<-summary(model.lme)

# Variance components
vc<-exp(2*attr(model.lme$apVar,'Pars'))
sa<-vc[1]
sab<-vc[2]
sag<-vc[3]
se<-model.lme$sigma^2
S<-4*(vc%*%t(vc))*model.lme$apVar[1:4,1:4]  # Var-cov of variance components

# Dimensions
ns<-length(unique(dataset$ind))
nt<-length(unique(dataset$time))
nm<-length(unique(dataset$method))

b<-as.matrix(model.lme$coef$fixed)

# Design matrix
nd<-nm*(nm-1)/2
if (length(covar)==0){
C<-array(0,dim=c((1+(nm-1)+(nt-1)+(nm-1)*(nt-1)),nt*nm))
k<-0
for (i in 1:nm){
for (j in 1:nt){
k<-k+1
C[,k]<-c(1,contrasts(dataset$method)[i,],contrasts(dataset$time)[j,],c((contrasts(dataset$method)[i,]%o%contrasts(dataset$time)[j,])))
}
}
                    }

if (length(covar)>0){
CC<-array(0,dim=c((1+(nm-1)+(nt-1)+(nm-1)*(nt-1)+length(covar)),nt*nm))
k<-0
for (i in 1:nm){
for (j in 1:nt){
k<-k+1
CC[,k]<-c(1,contrasts(dataset$method)[i,],contrasts(dataset$time)[j,],rep(1,length(covar)),c((contrasts(dataset$method)[i,]%o%contrasts(dataset$time)[j,])))
}
}
C=CC
X.sel=as.matrix(dataset[,(2+(nm-1)+(nt-1)+1):(2+(nm-1)+(nt-1)+length(covar))])
for (i in 1:length(covar)){
C[(1+(nm-1)+(nt-1)+i),]=apply(matrix(apply(matrix(X.sel[,i],nrow=nL),2,mean),nrow=nm*nt),1,mean)
}
                    }                

bdiag<-function(x){
     if(!is.list(x)) stop("x not a list")
     n <- length(x)
     if(n==0) return(NULL)
     x <- lapply(x, function(y) if(length(y)) as.matrix(y) else
stop("Zero-length component in x"))
     d <- array(unlist(lapply(x, dim)), c(2, n))
     rr <- d[1,]
     cc <- d[2,]
     rsum <- sum(rr)
     csum <- sum(cc)
     out <- array(0, c(rsum, csum))
     ind <- array(0, c(4, n))
     rcum <- cumsum(rr)
     ccum <- cumsum(cc)
     ind[1,-1] <- rcum[-n]
     ind[2,] <- rcum
     ind[3,-1] <- ccum[-n]
     ind[4,] <- ccum
     imat <- array(1:(rsum * csum), c(rsum, csum))
     iuse <- apply(ind, 2, function(y, imat) imat[(y[1]+1):y[2],
(y[3]+1):y[4]], imat=imat)
     iuse <- as.vector(unlist(iuse))
     out[iuse] <- unlist(x)
     return(out)
}

#Weigths matrix
if (nd ==1) auxD<-D
if (nd > 1) {
auxD<-bdiag(list(D,D))
cont<-2
while(cont<nd){
cont<-cont+1
auxD=bdiag(list(auxD,D))
}
}

# Difference between methods matrix
L<-array(0,dim=c(length(b),nt*nd))
k<-0
for (i in 1:(nm-1)){
for (ii in (i+1):nm){
for (j in 1:nt){
k<-k+1
L[,k]=C[,(i-1)*nt+j]-C[,(ii-1)*nt+j]
}
}
}

Sb<-model.lme$varFix# Var-cov of fixed effects

difmed<-t(L)%*%b
A<-L%*%auxD%*%t(L)

aux1<-(t(difmed)%*%auxD%*%difmed)-sum(diag((A%*%Sb)))
sb<-max(aux1/(nm*(nm-1)),0)
sumd<-sum(diag(D))
sumd.off<-sum(D)-sumd

# calculating the CCC;
den<-(sumd*(sa+sab+sag+se/nL)+sumd.off*(sa+sab))+sb
ccc<-(sumd*(sa+sag)+sumd.off*sa)/den

# calculating the inter-CCC;
interden<-(sumd*(sa+sab+sag)+sumd.off*(sa+sab))+sb
interccc<-(sumd*(sa+sag)+sumd.off*sa)/interden

intraden<-((sa+sab+sag+se)*sum(D))
intraICCW=((sa+sab+sag)*sumd+(sa+sab)*sumd.off)/intraden

# Variance of between-observers variability;
var.sb<-((2*sum(diag(((A%*%Sb)**2))))+(4*(t(b)%*%A%*%Sb%*%A%*%b)))/((nm*(nm-1))^2)

v1=array(1,c(nt*nL,nt*nL))
v2=diag(1,nt*nL)
dsa=array(1,c(nm*nt*nL,nm*nt*nL))
dsab=kronecker(diag(1,nm),v1)
dsag=kronecker(array(1,c(nm,nm)),v2)
dse=diag(1,nm*nt*nL)

dev.sa<-sum(D)*(1-ccc)/den
dev.sag<-sumd*(1-ccc)/den
dev.sb<-(-1)*ccc/den
if (sb==0) dev.sb<-0
dev.sab<-sum(D)*(-1)*ccc/den
dev.se<-sumd*(-1)*ccc/den
dev<-array(c(dev.sa,dev.sab,dev.sag,dev.se,dev.sb),dim=c(1,5))

Y.VarY=sa*dsa+sab*dsab+sag*dsag+se*dse
v=solve(Y.VarY)

repC=matrix(0,nrow=nrow(C),ncol=ncol(C)*nL)
for (i in 1:ncol(C)){
j=(i-1)*nL
repC[,(1+j):(nL+j)]=C[,i]
}

datax=kronecker(array(1,c(ns,1)),repC)

for(i in 1:ns){
j=(i-1)
datax[((4+6*j):(5+6*j)),(1:8)]=t(dataset[((1+8*j):(8*(j+1))),(5:6)])}

ddsa=matrix(0,nrow=(nm*nt+length(covar)),ncol=(nm*nt+length(covar)))
for(i in 1:ns){
j=(i-1)*(nm*nt+length(covar))
ddsa=ddsa+A%*%Sb%*%datax[(1+j):(nm*nt+length(covar)+j), ]%*%v%*%dsa%*%v%*%t(datax[(1+j):(nm*nt+length(covar)+j), ])%*%Sb
}
cov.sasb=(-1/(nm*(nm-1)))* sum(diag(ddsa))*S[1,1]
ddsab=matrix(0,nrow=(nm*nt+length(covar)),ncol=(nm*nt+length(covar)))
for(i in 1:ns){
j=(i-1)*nm*nt
ddsab=ddsab+A%*%Sb%*%datax[(1+j):(nm*nt+length(covar)+j), ]%*%v%*%dsab%*%v%*%t(datax[(1+j):(nm*nt+length(covar)+j), ])%*%Sb
}
cov.sabsb=(-1/(nm*(nm-1)))* sum(diag(ddsab))*S[2,2]
ddsag=matrix(0,nrow=(nm*nt+length(covar)),ncol=(nm*nt+length(covar)))
for(i in 1:ns){
j=(i-1)*nm*nt
ddsag=ddsag+A%*%Sb%*%datax[(1+j):(nm*nt+length(covar)+j), ]%*%v%*%dsag%*%v%*%t(datax[(1+j):(nm*nt+length(covar)+j), ])%*%Sb
}
cov.sagsb=(-1/(nm*(nm-1)))* sum(diag(ddsag))*S[3,3]
ddse=matrix(0,nrow=(nm*nt+length(covar)),ncol=(nm*nt+length(covar)))
for(i in 1:ns){
j=(i-1)*nm*nt
ddse=ddse+A%*%Sb%*%datax[(1+j):(nm*nt+length(covar)+j), ]%*%v%*%dse%*%v%*%t(datax[(1+j):(nm*nt+length(covar)+j), ])%*%Sb
}
cov.sesb=(-1/(nm*(nm-1)))* sum(diag(ddse))*S[4,4]

S2<-array(,c(5,5))
S2[1:4,1:4]<-S
S2[5,]<-c(cov.sasb,cov.sabsb,cov.sagsb,cov.sesb,var.sb)
S2[1:4,5]<-c(cov.sasb,cov.sabsb,cov.sagsb,cov.sesb)

varcomp<-c(sa,sab,sag,sb,se)
names(varcomp)<-c("Subjects","Subjects-Method","Subjects-Time","Method","Error")
est<-ic.ccc(ccc,dev,S2)

# dev: Vector of derivatives(interccc&intraccc);
interdev.sa<-sum(D)*(1-interccc)/interden
interdev.sag<-sumd*(1-interccc)/interden
interdev.sb<-(-1)*interccc/interden
if (sb==0) interdev.sb<-0
interdev.sab<-sum(D)*(-1)*interccc/interden
interdev<-array(c(interdev.sa,interdev.sab,interdev.sag,0,interdev.sb),dim=c(1,5))
interest<-ic.ccc(interccc,interdev,S2)

devintra.sanew= (1-intraICCW)*sum(D)/intraden
devintra.sabnew=(1-intraICCW)*sum(D)/intraden
devintra.sagnew=(sumd-intraICCW*sum(D))/intraden
devintra.senew=((-1) *intraICCW*sum(D))/intraden

devintra.all<-array(c(devintra.sanew,devintra.sabnew,devintra.sagnew,devintra.senew,0),dim=c(1,5))
intraest<-ic.ccc(intraICCW,devintra.all,S2)

res<-list(ccc.p=ccc,ccc.i=c(intraest,interest,est),vc=varcomp,sigma=S2,model=model,nonpd=0)
class(res)<-"ccclonw"
res}
res
}



#################### the VC approach for OBS ####################
ccclonw.default.obs<-function(dataset,y,ind,method,time,D,covar,rho,nL){
dataset$ind<-as.factor(dataset$ind)
dataset$method<-as.factor(dataset$method)
dataset$time2<-as.numeric(dataset$time)
dataset$time<-as.factor(dataset$time)
dataset$y<-as.numeric(dataset$y)

form=y~method+time+method*time
if (length(covar)>0){
new.covar <- covar[1]
for(ii in c(2:length(covar))){ new.covar <- paste(new.covar, covar[ii], sep="+") }
form<-as.formula(paste("y~method+time+method*time",new.covar,sep="+"))}

model.lme=NULL
#Coumpund simmetry model
tryCatch({model.lme<-lme(form,dataset,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time)))))  }, error=function(e){})

if(length(model.lme)==0|is.character(model.lme$apVar)==TRUE){
#stop("Non-positive definite approximate variance-covariance")
res<-list(ccc.p=NULL,ccc.i=rep(0,18),vc=rep(0,5),sigma=NULL,model=NULL,nonpd=1)
class(res)<-"ccclonw"
res}

if(length(model.lme)!=0&is.character(model.lme$apVar)==FALSE){
nonpd=0

model<-summary(model.lme)

# Variance components
vc<-exp(2*attr(model.lme$apVar,'Pars'))
sa<-vc[1]
sab<-vc[2]
sag<-vc[3]
se<-model.lme$sigma^2
S<-4*(vc%*%t(vc))*model.lme$apVar[1:4,1:4]  # Var-cov of variance components

# Dimensions
ns<-length(unique(dataset$ind))
nt<-length(unique(dataset$time))
nm<-length(unique(dataset$method))

b<-as.matrix(model.lme$coef$fixed)

# Design matrix
nd<-nm*(nm-1)/2
if (length(covar)==0){
C<-array(0,dim=c((1+(nm-1)+(nt-1)+(nm-1)*(nt-1)),nt*nm))
k<-0
for (i in 1:nm){
for (j in 1:nt){
k<-k+1
C[,k]<-c(1,contrasts(dataset$method)[i,],contrasts(dataset$time)[j,],c((contrasts(dataset$method)[i,]%o%contrasts(dataset$time)[j,])))
}
}
                    }

X.sel=as.matrix(dataset[,(2+(nm-1)+(nt-1)+1):(2+(nm-1)+(nt-1)+length(covar))])
Xmean<-matrix(0,nrow=length(covar),ncol=nm*nt)
if (length(covar)>0){
CC<-array(0,dim=c((1+(nm-1)+(nt-1)+(nm-1)*(nt-1)+length(covar)),nt*nm))
k<-0
for (i in 1:nm){
for (j in 1:nt){
k<-k+1
CC[,k]<-c(1,contrasts(dataset$method)[i,],contrasts(dataset$time)[j,],rep(1,length(covar)),c((contrasts(dataset$method)[i,]%o%contrasts(dataset$time)[j,])))
Xmean[,k]<-apply(subset(X.sel,dataset$method==(i-1)&dataset$time==j),2,mean)
}
}
C=CC

for (i in 1:length(covar)){
C[(1+(nm-1)+(nt-1)+i),]=Xmean[i,]
}
                    }           
           
bdiag<-function(x){
     if(!is.list(x)) stop("x not a list")
     n <- length(x)
     if(n==0) return(NULL)
     x <- lapply(x, function(y) if(length(y)) as.matrix(y) else
stop("Zero-length component in x"))
     d <- array(unlist(lapply(x, dim)), c(2, n))
     rr <- d[1,]
     cc <- d[2,]
     rsum <- sum(rr)
     csum <- sum(cc)
     out <- array(0, c(rsum, csum))
     ind <- array(0, c(4, n))
     rcum <- cumsum(rr)
     ccum <- cumsum(cc)
     ind[1,-1] <- rcum[-n]
     ind[2,] <- rcum
     ind[3,-1] <- ccum[-n]
     ind[4,] <- ccum
     imat <- array(1:(rsum * csum), c(rsum, csum))
     iuse <- apply(ind, 2, function(y, imat) imat[(y[1]+1):y[2],
(y[3]+1):y[4]], imat=imat)
     iuse <- as.vector(unlist(iuse))
     out[iuse] <- unlist(x)
     return(out)
}

#Weigths matrix
if (nd ==1) auxD<-D
if (nd > 1) {
auxD<-bdiag(list(D,D))
cont<-2
while(cont<nd){
cont<-cont+1
auxD=bdiag(list(auxD,D))
}
}

# Difference between methods matrix
L<-array(0,dim=c(length(b),nt*nd))
k<-0
for (i in 1:(nm-1)){
for (ii in (i+1):nm){
for (j in 1:nt){
k<-k+1
L[,k]=C[,(i-1)*nt+j]-C[,(ii-1)*nt+j]
}
}
}

Sb<-model.lme$varFix# Var-cov of fixed effects

difmed<-t(L)%*%b
A<-L%*%auxD%*%t(L)

aux1<-(t(difmed)%*%auxD%*%difmed)-sum(diag((A%*%Sb)))
sb<-max(aux1/(nm*(nm-1)),0)
sumd<-sum(diag(D))
sumd.off<-sum(D)-sumd

# calculating the CCC;
den<-(sumd*(sa+sab+sag+se/nL)+sumd.off*(sa+sab))+sb
ccc<-(sumd*(sa+sag)+sumd.off*sa)/den

# calculating the inter-CCC;
interden<-(sumd*(sa+sab+sag)+sumd.off*(sa+sab))+sb
interccc<-(sumd*(sa+sag)+sumd.off*sa)/interden

intraden<-((sa+sab+sag+se)*sum(D))
intraICCW=((sa+sab+sag)*sumd+(sa+sab)*sumd.off)/intraden

# Variance of between-observers variability;
var.sb<-((2*sum(diag(((A%*%Sb)**2))))+(4*(t(b)%*%A%*%Sb%*%A%*%b)))/((nm*(nm-1))^2)

v1=array(1,c(nt*nL,nt*nL))
v2=diag(1,nt*nL)
dsa=array(1,c(nm*nt*nL,nm*nt*nL))
dsab=kronecker(diag(1,nm),v1)
dsag=kronecker(array(1,c(nm,nm)),v2)
dse=diag(1,nm*nt*nL)

dev.sa<-sum(D)*(1-ccc)/den
dev.sag<-sumd*(1-ccc)/den
dev.sb<-(-1)*ccc/den
if (sb==0) dev.sb<-0
dev.sab<-sum(D)*(-1)*ccc/den
dev.se<-sumd*(-1)*ccc/den
dev<-array(c(dev.sa,dev.sab,dev.sag,dev.se,dev.sb),dim=c(1,5))

Y.VarY=sa*dsa+sab*dsab+sag*dsag+se*dse
v=solve(Y.VarY)

repC=matrix(0,nrow=nrow(C),ncol=ncol(C)*nL)
for (i in 1:ncol(C)){
j=(i-1)*nL
repC[,(1+j):(nL+j)]=C[,i]
}

datax=kronecker(array(1,c(ns,1)),repC)

for(i in 1:ns){
j=(i-1)
datax[((4+6*j):(5+6*j)),dataset[which(dataset[,2]==i),7]]=t(dataset[which(dataset[,2]==i),(5:6)])}

ddsa=matrix(0,nrow=(nm*nt+length(covar)),ncol=(nm*nt+length(covar)))
for(i in 1:ns){
j=(i-1)*(nm*nt+length(covar))
ddsa=ddsa+A%*%Sb%*%datax[(1+j):(nm*nt+length(covar)+j),dataset[which(dataset[,2]==i),7]]%*%v[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%
dsa[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%v[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%
t(datax[(1+j):(nm*nt+length(covar)+j),dataset[which(dataset[,2]==i),7]])%*%Sb
}
cov.sasb=(-1/(nm*(nm-1)))* sum(diag(ddsa))*S[1,1]

ddsab=matrix(0,nrow=(nm*nt+length(covar)),ncol=(nm*nt+length(covar)))
for(i in 1:ns){
j=(i-1)*nm*nt
ddsab=ddsab+A%*%Sb%*%datax[(1+j):(nm*nt+length(covar)+j),dataset[which(dataset[,2]==i),7]]%*%v[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%
dsab[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%v[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%
t(datax[(1+j):(nm*nt+length(covar)+j),dataset[which(dataset[,2]==i),7]])%*%Sb
}
cov.sabsb=(-1/(nm*(nm-1)))* sum(diag(ddsab))*S[2,2]

ddsag=matrix(0,nrow=(nm*nt+length(covar)),ncol=(nm*nt+length(covar)))
for(i in 1:ns){
j=(i-1)*nm*nt
ddsag=ddsag+A%*%Sb%*%datax[(1+j):(nm*nt+length(covar)+j),dataset[which(dataset[,2]==i),7]]%*%v[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%
dsag[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%v[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%
t(datax[(1+j):(nm*nt+length(covar)+j),dataset[which(dataset[,2]==i),7]])%*%Sb
}
cov.sagsb=(-1/(nm*(nm-1)))* sum(diag(ddsag))*S[3,3]

ddse=matrix(0,nrow=(nm*nt+length(covar)),ncol=(nm*nt+length(covar)))
for(i in 1:ns){
j=(i-1)*nm*nt
ddse=ddse+A%*%Sb%*%datax[(1+j):(nm*nt+length(covar)+j),dataset[which(dataset[,2]==i),7]]%*%v[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%
dse[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%v[dataset[which(dataset[,2]==i),7],dataset[which(dataset[,2]==i),7]]%*%
t(datax[(1+j):(nm*nt+length(covar)+j),dataset[which(dataset[,2]==i),7]])%*%Sb
}
cov.sesb=(-1/(nm*(nm-1)))* sum(diag(ddse))*S[4,4]

S2<-array(,c(5,5))
S2[1:4,1:4]<-S
S2[5,]<-c(cov.sasb,cov.sabsb,cov.sagsb,cov.sesb,var.sb)
S2[1:4,5]<-c(cov.sasb,cov.sabsb,cov.sagsb,cov.sesb)

varcomp<-c(sa,sab,sag,sb,se)
names(varcomp)<-c("Subjects","Subjects-Method","Subjects-Time","Method","Error")
est<-ic.ccc(ccc,dev,S2)

# dev: Vector of derivatives(interccc&intraccc);
interdev.sa<-sum(D)*(1-interccc)/interden
interdev.sag<-sumd*(1-interccc)/interden
interdev.sb<-(-1)*interccc/interden
if (sb==0) interdev.sb<-0
interdev.sab<-sum(D)*(-1)*interccc/interden
interdev<-array(c(interdev.sa,interdev.sab,interdev.sag,0,interdev.sb),dim=c(1,5))
interest<-ic.ccc(interccc,interdev,S2)

devintra.sanew= (1-intraICCW)*sum(D)/intraden
devintra.sabnew=(1-intraICCW)*sum(D)/intraden
devintra.sagnew=(sumd-intraICCW*sum(D))/intraden
devintra.senew=((-1) *intraICCW*sum(D))/intraden

devintra.all<-array(c(devintra.sanew,devintra.sabnew,devintra.sagnew,devintra.senew,0),dim=c(1,5))
intraest<-ic.ccc(intraICCW,devintra.all,S2)

res<-list(ccc.p=ccc,ccc.i=c(intraest,interest,est),vc=varcomp,sigma=S2,model=model,nonpd=0)
class(res)<-"ccclonw"
res}
res
}



ic.ccc <-function(ccc,dev,S){
se.ccc <- sqrt(dev%*%S%*%t(dev))
z<-0.5*log((1+ccc)/(1-ccc))
se.z<-sqrt(  (se.ccc^2)/(((1+ccc)^2)*((1-ccc)^2))  )
ll.z<-z-qnorm(0.975)*se.z
ul.z<-z+qnorm(0.975)*se.z
ll95<- (exp(2*ll.z)-1)/(exp(2*ll.z)+1)
ul95<- (exp(2*ul.z)-1)/(exp(2*ul.z)+1)
result<-c(ccc,ll95,ul95,se.ccc,z,se.z)
names(result)<-c("CCC","LL CI95%","UL CI95%","SE CCC","Z","SE Z")
return(result)
}



#################### 95% coverage rate #################### 
coverage<-function(ccc,se.ccc,rhoc.true,i){
z<-0.5*log((1+ccc[i])/(1-ccc[i]))
se.z<-sqrt(  (se.ccc[i]^2)/(((1+ccc[i])^2)*((1-ccc[i])^2))  )
ll.z<-z-qnorm(0.975)*se.z
ul.z<-z+qnorm(0.975)*se.z
ll95<- (exp(2*ll.z)-1)/(exp(2*ll.z)+1)
ul95<- (exp(2*ul.z)-1)/(exp(2*ul.z)+1)
cover<-ifelse(rhoc.true<ul95 & rhoc.true>ll95,1,0)
cover
}



#################### Weight matrix ####################
DW.matrix=function(T,d){
DW=matrix(0,T,T)
for (i in 1:T){
   for (j in 1:T){
DW[i,j]=d^abs(i-j)}}
return(DW)}


