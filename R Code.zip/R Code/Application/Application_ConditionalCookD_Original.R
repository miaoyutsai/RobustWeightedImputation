# file name: Applicatgion_ConditionalCookD_Original.R: Conditional Cook's distance for the influential observation detection under the original threshold
##############################################################################################################################################################
#########################################       R code for the myopia twin study       ########################################      
##############################################################################################################################################################

source("D:\\Application_Allfunctions.R")

library(MASS);library(Matrix);library(nlme);library(mice);library(cccrm);library(doBy)
set.seed(30)

twinMDZ<-read.csv(file="d:\\twin.csv",header=T,na.strings = ".")
twinMZ<-subset(twinMDZ,MDZZ==1)
twinMZsort<-orderBy(~NO+twin1+loc,twinMZ)

M=1
n=40       
nm=2       
nt=2      
nL=2
DW=DW.matrix(nt,0)

  x0<-rep(1,n*nm*nt*nL)
  x1<-rep(rep(c(0,0,1,1),each=nL),n)
  x2<-rep(rep(c(0,1,0,1),each=nL),n)
  x3<-rep(rep(c(0,0,0,1),each=nL),n)

#The settings of parameters for missingness models
b1=-2.6
b2=0.08
b3=0.2
b4=-2.7
b5=0.08
b6=0.2

alldata<-twinMZsort
 #define Z 
  ai<-rep(1,nm*nt*nL)
  abi1<-rep(c(1,1,0,0),each=nL)
  abi2<-rep(c(0,0,1,1),each=nL)
  ari1<-rep(c(1,0,1,0),each=nL)
  ari2<-rep(c(0,1,0,1),each=nL)
  z<-cbind(ai,abi1,abi2,ari1,ari2)
  Z<-kronecker(diag(n),z)

prob_mis<-array(0,dim=c(n*nm*nt*nL,3,M)) 
orgin<-array(0,dim=c(n*nm*nt*nL,3,M))
colnames(orgin)<-c("y","x7","x6")
mis_number<-matrix(0,nrow=2,ncol=M) 

# parameters for the x7 model 
bi.x_record<-array(0,dim=c(2*n,5,M))
beta.x_record<-array(0,dim=c(3,5,M))
sigma.x_record<-array(0,dim=c(3,5,M))
x7_record<-array(0,dim=c(n*nm*nt*nL,5,M))

# parameters for the y model 
bi_record<-array(0,dim=c(ncol(z)*n,5,M))
beta_record<-array(0,dim=c(6,5,M))
sigma_record<-array(0,dim=c(4,5,M))
y_record<-array(0,dim=c(n*nm*nt*nL,5,M))

mis_Y<-mis_x7<-matrix(0,nrow=M,ncol=n*nm*nt*nL)

 ind=rep(1:n,each=(nm*nt*nL))
 method<-rep(1:nm,each=nt*nL,times=n)-1
 time<-rep(rep(1:nt,each=nL),times=(n*nm))
 repl<-rep(1:(nm*nt*nL),n)

for (r in (1:M)){
  xy_data<-as.data.frame(alldata)            
  x6<-xy_data$P
  prob_mis[,1,r]<-x6
  orgin[,3,r]<-x6
  y<-xy_data$y      
  orgin[,1,r]<-y
  mis_Y[r,]<-y        
  x7<-xy_data$AL    
  orgin[,2,r]<-x7
  mis_x7[r,]<-x7       
    
#Creating missing values
  for(i in (1:(n*nm*nt*nL))){
    ey<-exp(b1+b2*x6[i]+b3*method[i])
    ex<-exp(b4+b5*x6[i]+b6*y[i])
    p_y<-ey/(1+ey)
    p_x<-ex/(1+ex)
    prob_mis[i,2,r]<-p_y
    prob_mis[i,3,r]<-p_x
    my<-sample(c(1:2),1,prob=c(p_y,1-p_y))
    mx<-sample(c(1:2),1,prob=c(p_x,1-p_x))
    if(my==1&i%in%c(1:(n*nm*nt*nL))[-c(97:104,249:256)]){
      mis_Y[r,i]<-NA
    }
    if(mx==1&i%in%c(1:(n*nm*nt*nL))[-c(97:104,249:256)]){
      mis_x7[r,i]<-NA
    }
  }
}

alldatanew=alldata

cook.obs=matrix(0,nrow=n,ncol=M)
CD1.obs=matrix(0,nrow=n,ncol=M)
CD2.obs=matrix(0,nrow=n,ncol=M)

for (r in (1:M)){
  mis_number[1,r]<-length(which(is.na(mis_Y[r,])))
  mis_number[2,r]<-length(which(is.na(mis_x7[r,])))
  misY_obs<-which(is.na(mis_Y[r,]))
  misX_obs<-which(is.na(mis_x7[r,]))
  misXY_obs<-sort(union(misY_obs,misX_obs))
  mis_personY<-unique(ceiling(misY_obs/(nm*nt*nL)))
  mis_personX<-unique(ceiling(misX_obs/(nm*nt*nL)))

  y.old<-alldata[,4]            
  y<-y.old
  y[c(97:104)]=y[c(97:104)]-0.5
  y[c(249:256)]=y[c(249:256)]+2
  alldatanew[,4]=y
  
  xy_data<-as.data.frame(alldatanew)           
  y<-xy_data$y    
  x6<-xy_data$P  
  x7<-xy_data$AL
 
  com_data<-as.data.frame(cbind(y,ind,method,time,x6,x7,repl))
  colnames(com_data)<-c("y","ind","method","time","x6","x7","rep")
  com_data$y<-as.numeric(com_data$y)
  com_data$ind<-as.factor(com_data$ind)
  com_data$method<-as.factor(com_data$method)
  com_data$time<-as.factor(com_data$time)
  com_data$x6<-as.numeric(com_data$x6)
  com_data$x7<-as.numeric(com_data$x7)

  obs_data<-com_data[-misXY_obs,]
  colnames(obs_data)<-c("y","ind","method","time","x6","x7","rep")
  obs_data$y<-as.numeric(obs_data$y)
  obs_data$ind<-as.factor(obs_data$ind)
  obs_data$method<-as.factor(obs_data$method)
  obs_data$time<-as.factor(obs_data$time)
  obs_data$x6<-as.numeric(obs_data$x6)
  obs_data$x7<-as.numeric(obs_data$x7)
  
  form=y~method+time+method*time+x6+x7
tryCatch({model_obsXY<-lme(form,data=obs_data,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time)))))}, error=function(e){})  
    
  X.com<-cbind(x0,x1,x2,com_data$x6,com_data$x7,x3)
  X0.obs<-cbind(x0,x1,x2,com_data$x6,com_data$x7,x3)[-misXY_obs,]

if(length(model_obsXY)!=0&is.character(model_obsXY$apVar)==FALSE){  
  vc.hat<-exp(2*attr(model_obsXY$apVar,'Pars')) 
  sa.hat<-vc.hat[1]
  sab.hat<-vc.hat[2]
  sag.hat<-vc.hat[3]
  se.hat<-model_obsXY$sigma^2
  beta.hat<-summary(model_obsXY)$tTable[,1]

D.hat<-diag(c(sa.hat,rep(sab.hat,nm),rep(sag.hat,nt)))
V0.hat<-diag(se.hat,n*nm*nt*nL)+Z%*%kronecker(diag(n),D.hat)%*%t(Z)
V0.hat.obs<-V0.hat[-misXY_obs,-misXY_obs]

n1=length(unique(com_data[-misXY_obs,2]))
obs1=as.numeric(unique(com_data[-misXY_obs,2]))
for (i in 1:n){
obs_data.del<-com_data[-misXY_obs,]
biall.del<-matrix(0,nrow=n1,ncol=1+nm+nt)
obs.num=which(obs_data[,2]==i)

if (length(obs.num)>0){
obs_data.del<-obs_data[-obs.num,]
tryCatch({model_obsXY.del<-lme(form,data=obs_data.del,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time)))))}, error=function(e){})  

if(length(model_obsXY.del)!=0&is.character(model_obsXY.del$apVar)==FALSE){  

  vc.hat.del<-exp(2*attr(model_obsXY.del$apVar,'Pars')) 
  sa.hat.del<-vc.hat.del[1]
  sab.hat.del<-vc.hat.del[2]
  sag.hat.del<-vc.hat.del[3]
  se.hat.del<-model_obsXY.del$sigma^2
  beta.hat.del<-summary(model_obsXY.del)$tTable[,1]

D.hat.del<-diag(c(sa.hat.del,rep(sab.hat.del,nm),rep(sag.hat.del,nt)))
V0.hat.del<-diag(se.hat.del,n*nm*nt*nL)+Z%*%kronecker(diag(n),D.hat.del)%*%t(Z)
V0.hat.obs.del<-V0.hat.del[-misXY_obs,-misXY_obs]
V0.hat.obs.del<-V0.hat.obs.del[obs.num,obs.num]
bi.del=D.hat.del%*%t(matrix(z[obs_data[obs.num, 7],],nrow=length(obs.num)))%*%solve(V0.hat.obs.del)%*%
       (obs_data[obs.num,1]-X0.obs[obs.num,]%*%beta.hat.del)
biall.del[-which(obs1==i),]=model_obsXY.del$coefficients$random$ind
biall.del[which(obs1==i),]=bi.del
ita.del=X0.obs[obs.num,]%*%beta.hat.del+matrix(z[obs_data[obs.num, 7],],nrow=length(obs.num))%*%bi.del

ita.obs.del<-rep(0,nrow(obs_data))
ita.obs.del[-obs.num]=model_obsXY.del$fitted[,1]
ita.obs.del[obs.num]=ita.del

cook.obs[i,r]=1/se.hat*t(model_obsXY$fitted[,1]-ita.obs.del)%*%(model_obsXY$fitted[,1]-ita.obs.del)/((n1-1)*(1+nm+nt)+ncol(X0.obs))
CD1.obs[i,r]=1/se.hat*t(beta.hat-beta.hat.del)%*%t(X0.obs)%*%X0.obs%*%(beta.hat-beta.hat.del)/((n1-1)*(1+nm+nt)+ncol(X0.obs))
CD2.obs[i,r]=1/se.hat*t(c(t(model_obsXY$coefficients$random$ind))-c(t(biall.del)))%*%t(Z[-misXY_obs,1:(n1*(1+nm+nt))])%*%
             Z[-misXY_obs,1:(n1*(1+nm+nt))]%*%(c(t(model_obsXY$coefficients$random$ind))-c(t(biall.del)))/
             ((n1-1)*(1+nm+nt)+ncol(X0.obs))
}}

if(length(obs.num)==0|length(model_obsXY.del)==0&is.character(model_obsXY.del$apVar)==TRUE)
{cook.obs[i,r]=0;CD1.obs[i,r]=0;CD2.obs[i,r]=0}
}}

if(length(model_obsXY)==0&is.character(model_obsXY$apVar)==TRUE){cook.obs[,r]=0;CD1.obs[,r]=0;CD2.obs[,r]=0}
}

mean.cook=rep(0,M)
mean.CD1=rep(0,M)
mean.CD2=rep(0,M)
outlier.select<-matrix(0,nrow=n,ncol=M)
outlier.select.CD1<-matrix(0,nrow=n,ncol=M)
outlier.select.CD2<-matrix(0,nrow=n,ncol=M)
for (r in 1:M){
mean.cook[r]=4*mean(cook.obs[,r])
mean.CD1[r]=4*mean(CD1.obs[,r])
mean.CD2[r]=4*mean(CD2.obs[,r])
for (i in 1:n){
outlier.select[i,r]=ifelse(cook.obs[i,r]>mean.cook[r],1,0)
outlier.select.CD1[i,r]=ifelse(CD1.obs[i,r]>mean.CD1[r],1,0)
outlier.select.CD2[i,r]=ifelse(CD2.obs[i,r]>mean.CD2[r],1,0)
}
}

save.image("D:\\Application_COOKD.RData")


