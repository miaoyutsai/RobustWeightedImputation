# file name: Applicatgion_ProposedLRT.R: Proposed likelihood ratio test for the outlier detection 
##############################################################################################################################################################
#########################################       R code for the myopia twin study       ########################################      
##############################################################################################################################################################

source("D:\\Application_Allfunctions.R")

library(MASS);library(Matrix);library(nlme);library(mice);library(cccrm);library(doBy)
set.seed(30)

twinMDZ<-read.csv(file="d:\\twin.csv",header=T,na.strings = ".")
twinMZ<-subset(twinMDZ,MDZZ==1)
twinMZsort<-orderBy(~NO+twin1+loc,twinMZ)

M=1
n=40       
nm=2       
nt=2      
nL=2
Bnum=1000
DW=DW.matrix(nt,0)

  x0<-rep(1,n*nm*nt*nL)
  x1<-rep(rep(c(0,0,1,1),each=nL),n)
  x2<-rep(rep(c(0,1,0,1),each=nL),n)
  x3<-rep(rep(c(0,0,0,1),each=nL),n)

#The settings of parameters for missingness models
b1=-2.6
b2=0.08
b3=0.2
b4=-2.7
b5=0.08
b6=0.2

alldata<-twinMZsort

 #define Z 
  ai<-rep(1,nm*nt*nL)
  abi1<-rep(c(1,1,0,0),each=nL)
  abi2<-rep(c(0,0,1,1),each=nL)
  ari1<-rep(c(1,0,1,0),each=nL)
  ari2<-rep(c(0,1,0,1),each=nL)
  z<-cbind(ai,abi1,abi2,ari1,ari2)
  Z<-kronecker(diag(n),z)

prob_mis<-array(0,dim=c(n*nm*nt*nL,3,M)) 
orgin<-array(0,dim=c(n*nm*nt*nL,3,M))
colnames(orgin)<-c("y","x7","x6")
mis_number<-matrix(0,nrow=2,ncol=M) 

# parameters for the x7 model 
bi.x_record<-array(0,dim=c(2*n,5,M))
beta.x_record<-array(0,dim=c(3,5,M))
sigma.x_record<-array(0,dim=c(3,5,M))
x7_record<-array(0,dim=c(n*nm*nt*nL,5,M))

# parameters for the y model 
bi_record<-array(0,dim=c(ncol(z)*n,5,M))
beta_record<-array(0,dim=c(6,5,M))
sigma_record<-array(0,dim=c(4,5,M))
y_record<-array(0,dim=c(n*nm*nt*nL,5,M))

mis_Y<-mis_x7<-matrix(0,nrow=M,ncol=n*nm*nt*nL)

 ind=rep(1:n,each=(nm*nt*nL))
 method<-rep(1:nm,each=nt*nL,times=n)-1
 time<-rep(rep(1:nt,each=nL),times=(n*nm))
 repl<-rep(1:(nm*nt*nL),n)

for (r in (1:M)){
  xy_data<-as.data.frame(alldata)            
  x6<-xy_data$P
  prob_mis[,1,r]<-x6
  orgin[,3,r]<-x6
  y<-xy_data$y      
  orgin[,1,r]<-y
  mis_Y[r,]<-y        
  x7<-xy_data$AL    
  orgin[,2,r]<-x7
  mis_x7[r,]<-x7       
    
#Creating missing values
  for(i in (1:(n*nm*nt*nL))){
    ey<-exp(b1+b2*x6[i]+b3*method[i])
    ex<-exp(b4+b5*x6[i]+b6*y[i])
    p_y<-ey/(1+ey)
    p_x<-ex/(1+ex)
    prob_mis[i,2,r]<-p_y
    prob_mis[i,3,r]<-p_x
    my<-sample(c(1:2),1,prob=c(p_y,1-p_y))
    mx<-sample(c(1:2),1,prob=c(p_x,1-p_x))
    if(my==1&i%in%c(1:(n*nm*nt*nL))[-c(97:104,249:256)]){
      mis_Y[r,i]<-NA
    }
    if(mx==1&i%in%c(1:(n*nm*nt*nL))[-c(97:104,249:256)]){
      mis_x7[r,i]<-NA
    }
  }
}

alldatanew=alldata

like.H0=RSS0.obs=rep(0,M)
like.H1=RSS1.obs=matrix(0,nrow=n,ncol=M)
LRT.oringal=F.oringal=matrix(0,nrow=n,ncol=M)

like.h0=matrix(0,nrow=Bnum,ncol=M)
like.h1=array(0,dim=c(n,Bnum,M))
LRT.boots=array(0,dim=c(n,Bnum,M))
quant.LRT=matrix(0,nrow=n,ncol=M)

for (r in (1:M)){
  mis_number[1,r]<-length(which(is.na(mis_Y[r,])))
  mis_number[2,r]<-length(which(is.na(mis_x7[r,])))
  misY_obs<-which(is.na(mis_Y[r,]))
  misX_obs<-which(is.na(mis_x7[r,]))
  misXY_obs<-sort(union(misY_obs,misX_obs))
  mis_personY<-unique(ceiling(misY_obs/(nm*nt*nL)))
  mis_personX<-unique(ceiling(misX_obs/(nm*nt*nL)))

  y.old<-alldata[,4]            
  y<-y.old
  y[c(97:104)]=y[c(97:104)]-0.5
  y[c(249:256)]=y[c(249:256)]+2
  alldatanew[,4]=y
  
  xy_data<-as.data.frame(alldatanew)            
  y<-xy_data$y    
  x6<-xy_data$P  
  x7<-xy_data$AL
  
  com_data<-as.data.frame(cbind(y,ind,method,time,x6,x7,repl))
  colnames(com_data)<-c("y","ind","method","time","x6","x7","rep")
  com_data$y<-as.numeric(com_data$y)
  com_data$ind<-as.factor(com_data$ind)
  com_data$method<-as.factor(com_data$method)
  com_data$time<-as.factor(com_data$time)
  com_data$x6<-as.numeric(com_data$x6)
  com_data$x7<-as.numeric(com_data$x7)

  obs_data<-com_data[-misXY_obs,]
  colnames(obs_data)<-c("y","ind","method","time","x6","x7","rep")
  obs_data$y<-as.numeric(obs_data$y)
  obs_data$ind<-as.factor(obs_data$ind)
  obs_data$method<-as.factor(obs_data$method)
  obs_data$time<-as.factor(obs_data$time)
  obs_data$x6<-as.numeric(obs_data$x6)
  obs_data$x7<-as.numeric(obs_data$x7)
  
  form=y~method+time+method*time+x6+x7
tryCatch({model_obsXY<-lme(form,data=obs_data,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time)))),method="ML")}, error=function(e){})  
    
   X.com<-cbind(x0,x1,x2,com_data$x6,com_data$x7,x3)

if(length(model_obsXY)!=0&is.character(model_obsXY$apVar)==FALSE){  
  vc.hat<-exp(2*attr(model_obsXY$apVar,'Pars')) 
  sa.hat<-vc.hat[1]
  sab.hat<-vc.hat[2]
  sag.hat<-vc.hat[3]
  se.hat<-model_obsXY$sigma^2
  beta.hat<-summary(model_obsXY)$tTable[,1]

D.hat<-diag(c(sa.hat,rep(sab.hat,nm),rep(sag.hat,nt)))
V0.hat<-diag(1,n*nm*nt*nL)+Z%*%kronecker(diag(n),D.hat)%*%t(Z)/se.hat
V0.hat.obs<-V0.hat[-misXY_obs,-misXY_obs]
like.H0[r]<-summary(model_obsXY)$logLik 
RSS0.obs[r]<-t(model_obsXY$r[,1])%*%solve(V0.hat.obs)%*%model_obsXY$r[,1]/se.hat

X0.obs<-cbind(x0,x1,x2,com_data$x6,com_data$x7,x3)[-misXY_obs,]
Wx0Wx0t=diag(1,n*nm*nt*nL)[-misXY_obs,-misXY_obs]-X0.obs%*%solve(t(X0.obs)%*%X0.obs)%*%t(X0.obs)
tryCatch({Wx0=svd(Wx0Wx0t,nu=(n*nm*nt*nL)-ncol(X0.obs),nv=(n*nm*nt*nL)-ncol(X0.obs))$u},error=function(e){})
ws0=eigen(t(Wx0)%*%Z[-misXY_obs,]%*%kronecker(diag(n),D.hat)%*%t(Z[-misXY_obs,])%*%Wx0,symmetric=T)$values/se.hat
logws0=log(det(diag(1+ws0)))
}

xi<-ws<-phis<-matrix(0,nrow=(n*nm*nt*nL-length(misXY_obs)),ncol=n)
logphis<-logws<-rep(0,n)

  for (i in 1:n){
  d=rep(0,n*nm*nt*nL)
  d[(1+(i-1)*nm*nt*nL):(i*nm*nt*nL)]=1
  dmis=d[-misXY_obs]
   y<-xy_data$y    
  x6<-xy_data$P 
  x7<-xy_data$AL   
  
  ymis_data<-cbind(com_data,d)[-misXY_obs,]
  colnames(ymis_data)<-c("y","ind","method","time","x6","x7","rep","d")
  ymis_data$y<-as.numeric(ymis_data$y)
  ymis_data$ind<-as.factor(ymis_data$ind)
  ymis_data$method<-as.factor(ymis_data$method)
  ymis_data$time<-as.factor(ymis_data$time)
  ymis_data$x6<-as.numeric(ymis_data$x6)
  ymis_data$x7<-as.numeric(ymis_data$x7)

model.y=NULL
tryCatch({model.y<-lme(y~method+time+method*time+x6+x7+d,data=ymis_data,random=list(ind=pdBlocked(list(pdIdent(form=~1+d),pdIdent(form=~-1+method),pdIdent(form=~-1+time)))),method="ML") },error=function(e){})

if(length(model_obsXY)!=0&is.character(model_obsXY$apVar)==FALSE&length(model.y)!=0&is.character(model.y$apVar)==FALSE){
V1.hat.obs<-V0.hat.obs+dmis%*%t(dmis)*exp(2*attr(model.y$apVar,'Pars'))[1]/model.y$sigma^2
V.tuda.obs=solve(t(chol(V0.hat.obs)))%*%V1.hat.obs%*%solve(chol(V0.hat.obs))

X1.obs<-cbind(x0,x1,x2,com_data$x6,com_data$x7,d,x3)[-misXY_obs,]
X1.tuda.obs<-solve(t(chol(V0.hat.obs)))%*%cbind(x0,x1,x2,com_data$x6,com_data$x7,d,x3)[-misXY_obs,]
WWt=diag(1,n*nm*nt*nL)[-misXY_obs,-misXY_obs]-X1.tuda.obs%*%solve(t(X1.tuda.obs)%*%X1.tuda.obs)%*%t(X1.tuda.obs)
tryCatch({W=svd(WWt,nu=(n*nm*nt*nL)-ncol(X1.tuda.obs),nv=(n*nm*nt*nL)-ncol(X1.tuda.obs))$u},error=function(e){})

xi[,i]=eigen(t(W)%*%solve(t(chol(V0.hat.obs)))%*%dmis%*%t(dmis)%*%solve(chol(V0.hat.obs))%*%W,symmetric=T)$values*
       exp(2*attr(model.y$apVar,'Pars'))[1]/model.y$sigma^2

  vc.hat.y<-exp(2*attr(model.y$apVar,'Pars')) 
  sa.hat.y<-vc.hat.y[1]
  sab.hat.y<-vc.hat.y[2]
  sag.hat.y<-vc.hat.y[3]
  D.hat.y<-diag(c(sa.hat.y,rep(sab.hat.y,nm),rep(sag.hat.y,nt)))

WxWxt=diag(1,n*nm*nt*nL)[-misXY_obs,-misXY_obs]-X1.obs%*%solve(t(X1.obs)%*%X1.obs)%*%t(X1.obs)
tryCatch({Wx=svd(WxWxt,nu=(n*nm*nt*nL)-ncol(X1.obs),nv=(n*nm*nt*nL)-ncol(X1.obs))$u},error=function(e){})
ws[,i]=eigen(t(Wx)%*%Z[-misXY_obs,]%*%kronecker(diag(n),D.hat.y)%*%t(Z[-misXY_obs,])%*%Wx,symmetric=T)$values/model.y$sigma^2
logws[i]=log(det(diag(1+ws[,i])))
phis[,i]=eigen(t(Wx)%*%solve(t(chol(V0.hat.obs)))%*%dmis%*%t(dmis)%*%solve(chol(V0.hat.obs))%*%Wx,symmetric=T)$values*
         exp(2*attr(model.y$apVar,'Pars'))[1]/model.y$sigma^2
logphis[i]=log(det(diag(1+phis[,i])))

like.H1[i,r]<-model.y$logLik
RSS1.obs[i,r]<-t(model.y$r[,1])%*%solve(V1.hat.obs)%*%model.y$r[,1]/model.y$sigma^2
LRT.oringal[i,r]=-2*(like.H0[r]-like.H1[i,r])

for (B in 1:Bnum){
vs<-rnorm(n*nm*nt*nL-length(misXY_obs)-ncol(X0.obs))
us<-rnorm(n*nm*nt*nL-length(misXY_obs)-ncol(X1.obs))
like.h0[B,r]<--n*log(sum(vs^2))
like.h1[i,B,r]<--n*log(sum(us^2/(1+xi[1:(n*nm*nt*nL-length(misXY_obs)-ncol(X1.obs)),i])))-logphis[i]
LRT.boots[i,B,r]=-(like.h0[B,r]-like.h1[i,B,r]) 
}}
}
}

outlier.select<-matrix(0,nrow=n,ncol=M)
for (r in 1:M){
for (i in 1:n){
quant.LRT[i,r]=quantile(LRT.boots[i,,r],0.95)
outlier.select[i,r]=ifelse(LRT.oringal[i,r]>quant.LRT[i,r],1,0)
}}

save.image("D:\\Application_ProposedLRT.RData")

