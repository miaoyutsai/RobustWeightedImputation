Readme

R codes for the simulation studies 
simulation_study_Allfunctions.R: All functions for the simulation studies
simulation_study_1SDC.R: one-stage imputation approach involving outlier deletion using conditional Cook's distance, CDi
simulation_study_1SDL.R: one-stage imputation approach involving outlier deletion using the proposed LRT
simulation_study_1SMVC.R: robust one-stage imputation approach under MVSOM with detection of influential cases based on conditional Cook's distance, CDi
simulation_study_1SMVL.R: robust one-stage imputation approach under the MVSOM with the detection of outliers using the proposed LRT
simulation_study_1SMVM.R: robust one-stage imputation approach under MVSOM, MSOM or VSOM with detection of influential cases based on conditional Cook's distance, CDi, CDi1 and CDi2, respectively.
simulation_study_1SRLMM.R: one-stage imputation approaches using the robust estimation of LMMs 
simulation_study_1STRI.R: one-stage imputation approaches using the data trimming 
simulation_study_1SWI.R: weighted one-stage imputation approach based on the weight function of the local influence
simulation_study_1SWM.R: weighted one-stage imputation approach based on the weight function of the Mahalanobis distance
simulation_study_COM_OBS_1Stage.R: complete data analysis (COM), observed data analysis (OBS) and one-stage imputation approach without handling outliers (1-Stage)
simulation_study_ConditionalCookD.R: Conditional Cook's distance for the influential observation detection 
simulation_study_ProposedLRT.R: Proposed likelihood ratio test for the outlier detection 

R codes and data for the application
twin.csv: the longitudinal normal data of the myopia twin study
Application_Allfunctions.R: All functions for the application
Application_1SDC.R: one-stage imputation approach involving outlier deletion using conditional Cook's distance, CDi
Application_1SDL.R: one-stage imputation approach involving outlier deletion using the proposed LRT
Application_1SMVC.R: robust one-stage imputation approach under MVSOM with detection of influential cases based on conditional Cook's distance, CDi
Application_1SMVL.R: robust one-stage imputation approach under the MVSOM with the detection of outliers using the proposed LRT
Application_1SMVM.R: robust one-stage imputation approach under MVSOM, MSOM or VSOM with detection of influential cases based on conditional Cook's distance, CDi, CDi1 and CDi2, respectively.
Application_1SRLMM.R: one-stage imputation approaches using the robust estimation of LMMs 
Application_1STRI.R: one-stage imputation approaches using the data trimming 
Application_1SWI.R: weighted one-stage imputation approach based on the weight function of the local influence
Application_1SWM.R: weighted one-stage imputation approach based on the weight function of the Mahalanobis distance
Application_COM_OBS_1Stage.R: complete data analysis (COM), observed data analysis (OBS) and one-stage imputation approach without handling outliers (1-Stage)
Application_ConditionalCookD_Original: Conditional Cook's distance for the influential observation detection under the original threshold
Application_ProposedLRT.R: Proposed likelihood ratio test for the outlier detection 
