# file name: simulation_study_1SWI.R: weighted one-stage imputation approach based on the weight function of the local influence
##############################################################################################################################################################
#########################################       R code for Scenarios 1 and 2 in the simulation study       ########################################      
##############################################################################################################################################################

source("D:\\simulation_study_Allfunctions.R")

library(MASS);library(Matrix);library(nlme);library(mice);library(cccrm);library(psych)
set.seed(2)

M=500
n=30    
nm=2       
nt=3       
nL=2
nout=2
DW=DW.matrix(nt,0)

sa=1    
sab=1   
sag=1   
se=1     
beta.true<-c(-2.5,0.8,0.8,0.8,1.2,1.2,0.8,0.8)
vc.true<-c(sa,sab,sag,se)
 
  x0<-rep(1,n*nm*nt*nL)
  x1<-rep(rep(c(0,0,0,1,1,1),each=nL),n)
  x2<-rep(rep(c(0,1,0,0,1,0),each=nL),n)
  x3<-rep(rep(c(0,0,1,0,0,1),each=nL),n)
  x4<-rep(rep(c(0,0,0,0,1,0),each=nL),n)
  x5<-rep(rep(c(0,0,0,0,0,1),each=nL),n)
    
#parameters of the x7 model 
   beta0.x<-1
   beta1.x<-1
   beta.x=c(beta0.x,beta1.x,1)
   sa.x<-1
   sab.x<-1 
   se.x<-1
betax.true<-c(beta0.x,beta1.x)
vcx.true<-c(sa.x,sab.x,se.x)

#The settings of true parameters for missingness models
#Scenario 1 (Low missing rate)
b1=-3.5
b2=2
b3=1.5
b4=-7.5
b5=1
b6=1.2

#Scenario 2 (High missing rate)
#b1=-2.9
#b2=2
#b3=1.5
#b4=-6.7
#b5=1
#b6=1.2

alldata<-data_frame(n,nm,nt,nL,beta.true,sa,sab,sag,se,M,beta0.x,beta1.x,sa.x,sab.x,se.x,nout)
 #define Z 
  ai<-rep(1,nm*nt*nL)
  abi1<-rep(c(1,1,1,0,0,0),each=nL)
  abi2<-rep(c(0,0,0,1,1,1),each=nL)
  ari1<-rep(c(1,0,0,1,0,0),each=nL)
  ari2<-rep(c(0,1,0,0,1,0),each=nL)
  ari3<-rep(c(0,0,1,0,0,1),each=nL)
  z<-cbind(ai,abi1,abi2,ari1,ari2,ari3)
  Z<-kronecker(diag(n),z)

prob_mis<-array(0,dim=c(n*nm*nt*nL,3,M)) #�Ĥ@��Ox6, �ĤG��Oy�򥢾��v,�ĤT��Ox7�򥢾��v
orgin<-array(0,dim=c(n*nm*nt*nL,3,M))
colnames(orgin)<-c("y","x7","x6")
mis_number<-matrix(0,nrow=2,ncol=M) #�Ĥ@�C��A�ĤG�Cx7

# parameters for the x7 model 
bi.x_record<-array(0,dim=c(2*n,5,M))
beta.x_record<-array(0,dim=c(length(beta.x),5,M))
sigma.x_record<-array(0,dim=c(3,5,M))
x7_record<-array(0,dim=c(n*nm*nt*nL,5,M))

# parameters for the y model 
bi_record<-array(0,dim=c(ncol(z)*n,5,M))
beta_record<-array(0,dim=c(length(beta.true),5,M))
sigma_record<-array(0,dim=c(4,5,M))
y_record<-array(0,dim=c(n*nm*nt*nL,5,M))

mis_Y<-mis_x7<-matrix(0,nrow=M,ncol=n*nm*nt*nL)

 ind=rep(1:n,each=(nm*nt*nL))
 method<-rep(1:nm,each=nt*nL,times=n)-1
 time<-rep(rep(1:nt,each=nL),times=(n*nm))
 repl<-rep(1:(nm*nt*nL),n)
 outlier.y.num<-matrix(0,M,nout*nm*nt*nL)
 out.y<-matrix(0,M,nout)

for (r in (1:M)){
  xy_data<-as.data.frame(alldata[,,r])            
  x6<-xy_data$x6
  prob_mis[,1,r]<-x6
  orgin[,3,r]<-x6
  y<-xy_data$y      
  out.y[r,]=sort(rev(order(apply(matrix(y,nrow=n,ncol=nm*nt*nL,byrow=T),1,mean)))[1:nout])
  #out.y[r,]=c(1,n)
  outlier.y.num[r,]<-c(((out.y[r,1]-1)*nm*nt*nL+1):(out.y[r,1]*nm*nt*nL),((out.y[r,2]-1)*nm*nt*nL+1):(out.y[r,2]*nm*nt*nL))

  orgin[,1,r]<-y
  mis_Y[r,]<-y         
  x7<-xy_data$x7    
  orgin[,2,r]<-x7
  mis_x7[r,]<-x7       
    
#Creating missing values
for(i in (1:(n*nm*nt*nL))){
    ey<-exp(b1+b2*x6[i]+b3*method[i])
    ex<-exp(b4+b5*x6[i]+b6*y[i])
    p_y<-ey/(1+ey)
    p_x<-ex/(1+ex)
    prob_mis[i,2,r]<-p_y
    prob_mis[i,3,r]<-p_x
    my<-rbinom(1,1,prob=p_y)
    mx<-rbinom(1,1,prob=p_x)
    if(my==1&i%in%c(1:(n*nm*nt*nL))[-outlier.y.num[r,]]){
      mis_Y[r,i]<-NA
    }
    if(my==0&mx==1&i%in%c(1:(n*nm*nt*nL))[-outlier.y.num[r,]]){
      mis_x7[r,i]<-NA
    }
  }
}

LMMest.com<-LMMestnew.com<-matrix(0,M,19)
vcest.com<-vcestnew.com<-matrix(0,M,5)
LMMest.obs<-LMMestnew.obs<-matrix(0,M,19)
vcest.obs<-vcestnew.obs<-matrix(0,M,5)
rho.true<-matrix(0,M,3)
weight.y=matrix(0,nrow=M,ncol=n*nm*nt*nL)
powerall=rep(0,M)
alldatanew=alldata

for (r in (1:M)){
  y.old<-alldatanew[,1,r]           
  y<-y.old
  y[outlier.y.num[r,1:(1*nm*nt*nL)]]<-y.old[outlier.y.num[r,1:(1*nm*nt*nL)]]+
                                      1*(alldata[outlier.y.num[r,1:(1*nm*nt*nL)],2,r]+2)+
                                      rep(rnorm(1,0,2^0.5),each=nm*nt*nL)
  y[outlier.y.num[r,((1*nm*nt*nL)+1):(nout*nm*nt*nL)]]<-y.old[outlier.y.num[r,((1*nm*nt*nL)+1):(nout*nm*nt*nL)]]+
                                                        1*(alldata[outlier.y.num[r,((1*nm*nt*nL)+1):(nout*nm*nt*nL)],2,r]+2) 
  alldatanew[,1,r]<-y
 }

for (r in (1:M)){
  mis_number[1,r]<-length(which(is.na(mis_Y[r,])))
  mis_number[2,r]<-length(which(is.na(mis_x7[r,])))
  misY_obs<-which(is.na(mis_Y[r,]))
  misX_obs<-which(is.na(mis_x7[r,]))
  misXY_obs<-sort(union(misY_obs,misX_obs))
  mis_personY<-unique(ceiling(misY_obs/(nm*nt*nL)))
  mis_personX<-unique(ceiling(misX_obs/(nm*nt*nL)))
  
  xy_data<-as.data.frame(alldatanew[,,r])            
  y<-xy_data$y    
  x6<-xy_data$x6  
  x7<-xy_data$x7 

  com_data<-as.data.frame(cbind(y,ind,method,time,x6,x7,repl))
  colnames(com_data)<-c("y","ind","method","time","x6","x7","rep")
  com_data$y<-as.numeric(com_data$y)
  com_data$ind<-as.factor(com_data$ind)
  com_data$method<-as.factor(com_data$method)
  com_data$time<-as.factor(com_data$time)
  com_data$x6<-as.numeric(com_data$x6)
  com_data$x7<-as.numeric(com_data$x7)
  
  form=y~method+time+method*time+x6+x7
  model_complete<-lme(form,data=com_data,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time)))))

  vc1<-exp(2*attr(model_complete$apVar,'Pars'))
  if(length(vc1)<1){
    r<-r+1
    next
  }

cccrm.com=ccclonw.default(com_data,"y","ind","time","method",D=DW,covar=c("x6","x7"),rho=0,nL)
LMMest.com[r,]=c((cccrm.com)$ccc.i,(cccrm.com)$nonpd)
vcest.com[r,]=c((cccrm.com)$vc)
rho.true[r,]<-ccc.true(com_data,covar=c("x6","x7"),nL,DW,beta.true,sa,sab,sag,se)
  
  obs_data<-com_data[-misXY_obs,]
  colnames(obs_data)<-c("y","ind","method","time","x6","x7","rep")
  obs_data$y<-as.numeric(obs_data$y)
  obs_data$ind<-as.factor(obs_data$ind)
  obs_data$method<-as.factor(obs_data$method)
  obs_data$time<-as.factor(obs_data$time)
  obs_data$x6<-as.numeric(obs_data$x6)
  obs_data$x7<-as.numeric(obs_data$x7)
  
  form=y~method+time+method*time+x6+x7
  model_obsXY<-lme(form,data=obs_data,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time)))))  
  
  vc2<-exp(2*attr(model_obsXY$apVar,'Pars'))
  if(length(vc2)<1){
    r<-r+1
    next
  } 
  beta.obs<-summary(model_obsXY)$tTable[,1]

cccrm.obs=ccclonw.default.obs(obs_data,"y","ind","time","method",D=DW,covar=c("x6","x7"),rho=0,nL)
LMMest.obs[r,]=c((cccrm.obs)$ccc.i,(cccrm.obs)$nonpd)
vcest.obs[r,]=c((cccrm.obs)$vc)
  
   for (jj in 1:5){
   y<-xy_data$y    
   x6<-xy_data$x6
   x7<-xy_data$x7 
   
  xymis_data<-com_data[-misXY_obs,]
  colnames(xymis_data)<-c("y","ind","method","time","x6","x7","rep")
  xymis_data$y<-as.numeric(xymis_data$y)
  xymis_data$ind<-as.factor(xymis_data$ind)
  xymis_data$method<-as.factor(xymis_data$method)
  xymis_data$time<-as.factor(xymis_data$time)
  xymis_data$x6<-as.numeric(xymis_data$x6)
  xymis_data$x7<-as.numeric(xymis_data$x7)

model.x=NULL
tryCatch({model.x=lme(x7~x6+y,data=xymis_data,random=list(ind=pdDiag(form=~x6)))}, error=function(e){})

if(length(model.x)==0|is.character(model.x$apVar)==TRUE){
#stop("Non-positive definite approximate variance-covariance")
beta.x_record[,jj,r]<-0
sigma.x_record[,jj,r]<-0
bi.x_record[,jj,r]<-0
x7_record[,jj,r]<-0
}

if(length(model.x)!=0&is.character(model.x$apVar)==FALSE){
   b.x<-as.matrix(model.x$coef$fixed)
   Sb.x<-as.matrix(model.x$varFix)
   logvc.x<-as.matrix(attr(model.x$apVar,'Pars'))
   Slogvc.x<-model.x$apVar[1:3,1:3]

   beta.x_record[,jj,r]<-mvrnorm(1,b.x,Sb.x)
   sigma.x_record[,jj,r]<-exp(2*mvrnorm(1,logvc.x,Slogvc.x))

    X.x<-cbind(rep(1,n*nm*nt*nL),x6,y)
    Z.x<-cbind(rep(1,n*nm*nt*nL),x6)
    bi.x<-rep(0,n*2)

    for(ri in (1:n)){
     misxy=which(misXY_obs>=(nm*nt*nL*(ri-1)+1)&misXY_obs<=(nm*nt*nL*(ri)))
     mis.xy=which(c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))%in%misXY_obs[misxy])
     if (length(misxy)==0){X.xi<-X.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri)),];
                          Z.xi<-Z.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri)),];
                          x7.xx=x7[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))];
     GG.x<-ginv(t(Z.xi)%*%ginv(diag(sigma.x_record[3,jj,r],nm*nt*nL-length(mis.xy),nm*nt*nL-length(mis.xy)))%*%Z.xi+
           ginv(diag(sigma.x_record[1:2,jj,r])));
     bi.x[((ri-1)*2+1):(ri*2)]<-mvrnorm(1,diag(sigma.x_record[1:2,jj,r])%*%t(Z.xi)%*%ginv(Z.xi%*%diag(sigma.x_record[1:2,jj,r])%*%t(Z.xi)+
                                diag(sigma.x_record[3,jj,r],nm*nt*nL-length(mis.xy),nm*nt*nL-length(mis.xy)))%*%
                                (x7.xx-X.xi%*%beta.x_record[,jj,r]),GG.x)}

     if (length(misxy)>0){X.xi<-matrix(X.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.xy],],ncol=ncol(X.x));
                          Z.xi<-matrix(Z.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.xy],],ncol=ncol(Z.x));
                          x7.xx=x7[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.xy]]}
     
     if (length(misxy)>0 & length(misxy)<(nm*nt*nL)){  
     GG.x<-ginv(t(Z.xi)%*%ginv(diag(sigma.x_record[3,jj,r],nm*nt*nL-length(mis.xy),nm*nt*nL-length(mis.xy)))%*%Z.xi+
           ginv(diag(sigma.x_record[1:2,jj,r])));
     bi.x[((ri-1)*2+1):(ri*2)]<-mvrnorm(1,diag(sigma.x_record[1:2,jj,r])%*%t(Z.xi)%*%ginv(Z.xi%*%diag(sigma.x_record[1:2,jj,r])%*%t(Z.xi)+
                                diag(sigma.x_record[3,jj,r],nm*nt*nL-length(mis.xy),nm*nt*nL-length(mis.xy)))%*%
                                (x7.xx-X.xi%*%beta.x_record[,jj,r]), GG.x)}  

     if (length(misxy)==nm*nt*nL){bi.x[((ri-1)*2+1):(ri*2)]<-mvrnorm(1,rep(0,2),diag(sigma.x_record[1:2,jj,r]))}  

     if(ri %in% mis_personX){
        e.x<-mvrnorm(1,rep(0,nm*nt*nL),diag(sigma.x_record[3,jj,r],nm*nt*nL,nm*nt*nL))
        Xmis<-X.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri)),]%*%beta.x_record[,jj,r]+Z.x[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri)),]%*%bi.x[((ri-1)*2+1):(ri*2)]+e.x  
        for(j in (1:(nm*nt*nL))){
          if(is.na(mis_x7[r,(ri-1)*nm*nt*nL+j])){
            x7[(ri-1)*nm*nt*nL+j]<-Xmis[j]
          }
        }
      }
    }
    bi.x_record[,jj,r]<-bi.x
    x7_record[,jj,r]<-x7

  X<-cbind(x0,x1,x2,x3,xy_data$x6,x7,x4,x5) }    
  
  ymis_data<-cbind(com_data)[-misXY_obs,]
  colnames(ymis_data)<-c("y","ind","method","time","x6","x7","rep")
  ymis_data$y<-as.numeric(ymis_data$y)
  ymis_data$ind<-as.factor(ymis_data$ind)
  ymis_data$method<-as.factor(ymis_data$method)
  ymis_data$time<-as.factor(ymis_data$time)
  ymis_data$x6<-as.numeric(ymis_data$x6)
  ymis_data$x7<-as.numeric(ymis_data$x7)

model.li=model_obsXY
sigma.li=exp(2*attr(model.li$apVar,'Pars'))
Sb<-model.li$varFix
S<-4*(sigma.li%*%t(sigma.li))*model.li$apVar[1:4,1:4]  
SbS<-bdiag(list(Sb,S))

D.li=diag(c(sigma.li[1],rep(sigma.li[2],nm),rep(sigma.li[3],nt)))
R.li=diag(sigma.li[4],nm*nt*nL,nm*nt*nL)
Vi=z%*%D.li%*%t(z)+R.li
b.li<-as.matrix(model.li$coef$fixed)
d1<-diag(c(1,rep(0,nm),rep(0,nt)))
d2<-diag(c(0,rep(1,nm),rep(0,nt)))
d3<-diag(c(0,rep(0,nm),rep(1,nt)))
weight.temp=rep(0,n*nm*nt*nL)
weight.temp1=weight.temp[-misXY_obs]

for (i in 1:n){
 misxy=which(misXY_obs>=(nm*nt*nL*(i-1)+1)&misXY_obs<=(nm*nt*nL*i))
 mis.xy=which(c((nm*nt*nL*(i-1)+1):(nm*nt*nL*i))%in%misXY_obs[misxy])
 if (length(misxy)==0) {
dev.libera=t(X[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i),])%*%ginv(Vi)%*%(y[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i)]-
           X[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i),]%*%b.li)
dev.lisigma=-0.5*tr(ginv(Vi))+0.5*t(y[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i)]-X[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i),]%*%b.li)%*%
            ginv(Vi)%*%ginv(Vi)%*%(y[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i)]-X[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i),]%*%b.li)
dev.lid1=-0.5*tr(ginv(Vi)%*%z%*%d1%*%t(z))+0.5*t(y[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i)]-
         X[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i),]%*%b.li)%*%ginv(Vi)%*%z%*%d1%*%t(z)%*%ginv(Vi)%*%
         (y[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i)]-X[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i),]%*%b.li)
dev.lid2=-0.5*tr(ginv(Vi)%*%z%*%d2%*%t(z))+0.5*t(y[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i)]-
         X[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i),]%*%b.li)%*%ginv(Vi)%*%z%*%d2%*%t(z)%*%ginv(Vi)%*%
         (y[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i)]-X[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i),]%*%b.li)
dev.lid3=-0.5*tr(ginv(Vi)%*%z%*%d3%*%t(z))+0.5*t(y[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i)]-
         X[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i),]%*%b.li)%*%ginv(Vi)%*%z%*%d3%*%t(z)%*%ginv(Vi)%*%
         (y[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i)]-X[(nm*nt*nL*(i-1)+1):(nm*nt*nL*i),]%*%b.li)

weight.temp1[which(ymis_data[,2]==i)]<-t(c(dev.libera,dev.lid1,dev.lid2,dev.lid3,dev.lisigma))%*%SbS%*%
                                       c(dev.libera,dev.lid1,dev.lid2,dev.lid3,dev.lisigma)
}

if (length(misxy)>0 & length(misxy)<(nm*nt*nL)){
X1<-matrix(X[c((nm*nt*nL*(i-1)+1):(nm*nt*nL*i))[-mis.xy],],ncol=ncol(X))
z1<-matrix(z[c(1:(nm*nt*nL))[-mis.xy],],ncol=ncol(z))

dev.libera=t(X1)%*%ginv(Vi[-mis.xy,-mis.xy])%*%(y[c((nm*nt*nL*(i-1)+1):(nm*nt*nL*i))[-mis.xy]]-X1%*%b.li)
dev.lisigma=-0.5*tr(ginv(Vi[-mis.xy,-mis.xy]))+0.5*t(y[c((nm*nt*nL*(i-1)+1):(nm*nt*nL*i))[-mis.xy]]-
            X1%*%b.li)%*%ginv(Vi[-mis.xy,-mis.xy])%*%ginv(Vi[-mis.xy,-mis.xy])%*%
            (y[c((nm*nt*nL*(i-1)+1):(nm*nt*nL*i))[-mis.xy]]-X1%*%b.li)
dev.lid1=-0.5*tr(ginv(Vi[-mis.xy,-mis.xy])%*%z1%*%d1%*%t(z1))+
         0.5*t(y[c((nm*nt*nL*(i-1)+1):(nm*nt*nL*i))[-mis.xy]]-X1%*%b.li)%*%
         ginv(Vi[-mis.xy,-mis.xy])%*%z1%*%d1%*%t(z1)%*%ginv(Vi[-mis.xy,-mis.xy])%*%
         (y[c((nm*nt*nL*(i-1)+1):(nm*nt*nL*i))[-mis.xy]]-X1%*%b.li)
dev.lid2=-0.5*tr(ginv(Vi[-mis.xy,-mis.xy])%*%z1%*%d2%*%t(z1))+
         0.5*t(y[c((nm*nt*nL*(i-1)+1):(nm*nt*nL*i))[-mis.xy]]-X1%*%b.li)%*%
         ginv(Vi[-mis.xy,-mis.xy])%*%z1%*%d2%*%t(z1)%*%ginv(Vi[-mis.xy,-mis.xy])%*%
         (y[c((nm*nt*nL*(i-1)+1):(nm*nt*nL*i))[-mis.xy]]-X1%*%b.li)
dev.lid3=-0.5*tr(ginv(Vi[-mis.xy,-mis.xy])%*%z1%*%d3%*%t(z1))+
         0.5*t(y[c((nm*nt*nL*(i-1)+1):(nm*nt*nL*i))[-mis.xy]]-X1%*%b.li)%*%
         ginv(Vi[-mis.xy,-mis.xy])%*%z1%*%d3%*%t(z1)%*%ginv(Vi[-mis.xy,-mis.xy])%*%
         (y[c((nm*nt*nL*(i-1)+1):(nm*nt*nL*i))[-mis.xy]]-X1%*%b.li)

weight.temp1[which(ymis_data[,2]==i)]<-t(c(dev.libera,dev.lid1,dev.lid2,dev.lid3,dev.lisigma))%*%SbS%*%
                                       c(dev.libera,dev.lid1,dev.lid2,dev.lid3,dev.lisigma)
}
}

weight.y[r,-misXY_obs]=1/weight.temp1

weighty=ifelse(weight.y[r,]>1,1,weight.y[r,])
  ymis_data<-cbind(com_data,weighty)[-misXY_obs,]
  colnames(ymis_data)<-c("y","ind","method","time","x6","x7","rep","weighty")
  ymis_data$y<-as.numeric(ymis_data$y)
  ymis_data$ind<-as.factor(ymis_data$ind)
  ymis_data$method<-as.factor(ymis_data$method)
  ymis_data$time<-as.factor(ymis_data$time)
  ymis_data$x6<-as.numeric(ymis_data$x6)
  ymis_data$x7<-as.numeric(ymis_data$x7)
    
model.y=NULL
#Coumpund simmetry model
tryCatch({model.y<-lme(y~method+time+method*time+x6+x7,data=ymis_data,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time)))),weights =~I(weighty)) }, error=function(e){})

if(length(model.x)==0|is.character(model.x$apVar)==TRUE|length(model.y)==0|is.character(model.y$apVar)==TRUE){
#stop("Non-positive definite approximate variance-covariance")
beta_record[,jj,r]<-0
sigma_record[,jj,r]<-0
bi_record[,jj,r]<-0
y_record[,jj,r]<-0
}

if(length(model.x)!=0&is.character(model.x$apVar)==FALSE&length(model.y)!=0&is.character(model.y$apVar)==FALSE){

 b.y<-as.matrix(model.y$coef$fixed)
 Sb.y<-as.matrix(model.y$varFix)
 logvc.y<-as.matrix(attr(model.y$apVar,'Pars'))
 Slogvc.y<-model.y$apVar[1:4,1:4]

 beta_record[,jj,r]<-mvrnorm(1,b.y,Sb.y)
 sigma_record[,jj,r]<-exp(2*mvrnorm(1,logvc.y,Slogvc.y))

    bi.y<-rep(0,n*(1+nm+nt))
    for(ri in (1:n)){
     misy=which(misY_obs>=(nm*nt*nL*(ri-1)+1)&misY_obs<=(nm*nt*nL*(ri)))
     mis.y=which(c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))%in%misY_obs[misy])

     if (length(misy)==0){X.y=X[(nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri),];y.y=y[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))];z.y=z;
     GG.y<-ginv(t(z)%*%ginv(diag(sigma_record[4,jj,r],nm*nt*nL,nm*nt*nL))%*%z+
           ginv(diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))));
     bi.y.mean<-diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)%*%
          ginv(z.y%*%diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)+
          diag(sigma_record[4,jj,r],nm*nt*nL-length(mis.y),nm*nt*nL-length(mis.y)))%*%(y.y-X.y%*%beta_record[,jj,r]);
     bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]<-mvrnorm(1,bi.y.mean, GG.y)}

     if (length(misy)>0){X.y=matrix(X[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.y],],ncol=ncol(X));y.y=y[c((nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri))[-mis.y]];z.y=matrix(z[-mis.y,],ncol=ncol(z))}
          
     if (length(misy)>0 & length(misy)<(nm*nt*nL)){  
     GG.y<-ginv(t(z.y)%*%ginv(diag(sigma_record[4,jj,r],nm*nt*nL-length(mis.y),nm*nt*nL-length(mis.y)))%*%z.y+
           ginv(diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))));   
     bi.y.mean<-diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)%*%
                ginv(z.y%*%diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))%*%t(z.y)+
                diag(sigma_record[4,jj,r],nm*nt*nL-length(mis.y),nm*nt*nL-length(mis.y)))%*%(y.y-X.y%*%beta_record[,jj,r]);
     bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]<-mvrnorm(1,bi.y.mean, GG.y) }  
 
     if (length(misy)==nm*nt*nL){bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]<-mvrnorm(1,rep(0,(1+nm+nt)),diag(c(sigma_record[1,jj,r],rep(sigma_record[2,jj,r],nm),rep(sigma_record[3,jj,r],nt)))) } 
   
     if(ri %in% mis_personY){
        e<-mvrnorm(1,rep(0,nm*nt*nL),diag(sigma_record[4,jj,r],nm*nt*nL,nm*nt*nL))
        Ymis<-X[(nm*nt*nL*(ri-1)+1):(nm*nt*nL*ri),]%*%beta_record[,jj,r]+z%*%bi.y[((ri-1)*(1+nm+nt)+1):(ri*(1+nm+nt))]+e
        for(j in (1:(nm*nt*nL))){
          if(is.na(mis_Y[r,(nm*nt*nL*(ri-1)+j)])){
          y[(nm*nt*nL*(ri-1)+j)]<-Ymis[j]
          }
        }
      }
    }
    bi_record[,jj,r]<-bi.y 
    y_record[,jj,r]<-y
    }  }
}


LMMest<-LMMestnew<-array(0,dim=c(5,19,M))
vcest<-array(0,dim=c(5,5,M))
noimpute<-rep(1,M)

for(r in (1:M)){
  if(sum(y_record[,1,r])==0){
   noimpute[r]=ifelse(sum(y_record[,1,r])==0,0,1)
    r<-r+1
    next
  }
  xy_data<-as.data.frame(alldatanew[,,r]) 

  for(i in 1:5){
  y<-y_record[,i,r]
  x7<-x7_record[,i,r]
  dataset=data.frame(y,ind,method,time,xy_data$x6,x7)
  colnames(dataset)<-c("y","ind","method","time","x6","x7")
cccrm.est=ccclonw.default(dataset,"y","ind","time","method",D=DW,covar=c("x6","x7"),rho=0,nL)

LMMest[i,,r]=c((cccrm.est)$ccc.i,(cccrm.est)$nonpd)
vcest[i,,r]=c((cccrm.est)$vc)
}
}

MM=ifelse(length(which(noimpute==0|apply(LMMest[,1,],2,sum)==0))>0, M-length(which(noimpute==0|apply(LMMest[,1,],2,sum)==0)), M)
LMMestnew=LMMest
vcestnew=vcest
rho.truenew.old=rho.true
if(length(which(noimpute==0|apply(LMMest[,1,],2,sum)==0))>0) {
LMMestnew=LMMest[,,-which(noimpute==0|apply(LMMest[,1,],2,sum)==0)]
vcestnew=vcest[,,-which(noimpute==0|apply(LMMest[,1,],2,sum)==0)]
rho.truenew.old=rho.true[-which(noimpute==0|apply(LMMest[,1,],2,sum)==0),]
}

rho_post.old<-matrix(0,MM,ncol(LMMestnew))
rho_post_var.old<-matrix(0,MM,ncol(rho.truenew.old))

#rubin's rule
for (r in (1:MM)){

  nocon<-which(apply(LMMestnew[,,r],1,sum)==1) 
  nocon_number<-length(nocon)  
  
  m=5-nocon_number
 
if (nocon_number>0&nocon_number<4)  {rho_mean<-apply(LMMestnew[-nocon,,r],2,mean); Vw<-apply(as.matrix(LMMestnew[-nocon,c(4,10,16),r]^2),2,mean) }
if (nocon_number==4)  {rho_mean<-LMMestnew[-nocon,,r]; Vw<-as.matrix(LMMestnew[-nocon,c(4,10,16),r]^2) }
if (nocon_number==0)  {rho_mean<-apply(LMMestnew[,,r],2,mean); Vw<-apply(as.matrix(LMMestnew[,c(4,10,16),r]^2),2,mean) }

if (nocon_number>0&nocon_number<4)  { Vb<-apply(as.matrix(LMMestnew[-nocon,c(1,7,13),r]-matrix(rep(rho_mean[c(1,7,13)],m),nrow=m,ncol=ncol(rho.truenew.old),byrow=T))^2,2,sum)/(m-1) }
if (nocon_number==4)  { Vb<-0 }
if (nocon_number==0)  { Vb<-apply(as.matrix(LMMestnew[,c(1,7,13),r]-matrix(rep(rho_mean[c(1,7,13)],m),nrow=m,ncol=ncol(rho.truenew.old),byrow=T))^2,2,sum)/(m-1) }

#rubin's rule: total variance
Vt<-Vw+(1+1/m)*Vb  
  
  rho_post.old[r,]<-rho_mean
  rho_post_var.old[r,]<-Vt
 }

if (length(which(rho_post.old[,1]<0.01|rho_post_var.old[,1]==NaN))>0) {
rho_post=rho_post.old[-which(rho_post.old[,1]<0.01),]
rho_post_var=rho_post_var.old[-which(rho_post.old[,1]<0.01),]
rho.truenew=rho.truenew.old[-which(rho_post.old[,1]<0.01),]
}

if (length(which(rho_post.old[,1]<0.01|rho_post_var.old[,1]==NaN))==0) {
rho_post=rho_post.old
rho_post_var=rho_post_var.old
rho.truenew=rho.truenew.old
}

coverage.rho.post=rep(0,ncol(rho.truenew))
rhoest=rho_post[,c(1,7,13)]
for (j in 1:ncol(rho.truenew)){
coverage.rho.post[j]=mean(mapply(coverage,MoreArgs=list(ccc=rhoest[,j],se.ccc=rho_post_var[,j]^0.5,rhoc.true=rho.truenew[,j]), i=1:nrow(rho_post)), na.rm = TRUE)
}

mse.rho.post=apply((rho_post[,c(1,7,13)]-rho.truenew)^2,2,mean)
t(rbind(apply(rho_post[,c(1,7,13)]-rho.truenew,2,mean),apply(rho_post_var,2,mean),apply(rho_post[,c(1,7,13)],2,var),
mse.rho.post*10^3,coverage.rho.post))




