# file name: simulation_study_ProposedLRT.R: Proposed likelihood ratio test for the outlier detection 
##############################################################################################################################################################
#########################################       R code for Scenarios 1 and 2 in the simulation study       ########################################      
##############################################################################################################################################################

source("D:\\simulation_study_Allfunctions.R")

library(MASS);library(Matrix);library(nlme);library(mice);library(cccrm)
set.seed(2)

#The settings of true parameters
M=500
n=80     
nm=2       
nt=3       
nL=2
nout=2
Bnum=1000

DW=DW.matrix(nt,0)

sa=1    
sab=1   
sag=1   
se=1     
beta.true<-c(-2.5,0.8,0.8,0.8,1.2,1.2,0.8,0.8)
vc.true<-c(sa,sab,sag,se)
 
  x0<-rep(1,n*nm*nt*nL)
  x1<-rep(rep(c(0,0,0,1,1,1),each=nL),n)
  x2<-rep(rep(c(0,1,0,0,1,0),each=nL),n)
  x3<-rep(rep(c(0,0,1,0,0,1),each=nL),n)
  x4<-rep(rep(c(0,0,0,0,1,0),each=nL),n)
  x5<-rep(rep(c(0,0,0,0,0,1),each=nL),n)
    
#parameters of the x7 model 
   beta0.x<-1
   beta1.x<-1
   beta.x=c(beta0.x,beta1.x,1)
   sa.x<-1
   sab.x<-1 
   se.x<-1
betax.true<-c(beta0.x,beta1.x)
vcx.true<-c(sa.x,sab.x,se.x)

#The settings of true parameters for missingness models
#Scenario 1 (Low missing rate)
b1=-3.5
b2=2
b3=1.5
b4=-7.5
b5=1
b6=1.2

#Scenario 2 (High missing rate)
#b1=-2.9
#b2=2
#b3=1.5
#b4=-6.7
#b5=1
#b6=1.2

alldata<-data_frame(n,nm,nt,nL,beta.true,sa,sab,sag,se,M,beta0.x,beta1.x,sa.x,sab.x,se.x,nout)
 #define Z 
  ai<-rep(1,nm*nt*nL)
  abi1<-rep(c(1,1,1,0,0,0),each=nL)
  abi2<-rep(c(0,0,0,1,1,1),each=nL)
  ari1<-rep(c(1,0,0,1,0,0),each=nL)
  ari2<-rep(c(0,1,0,0,1,0),each=nL)
  ari3<-rep(c(0,0,1,0,0,1),each=nL)
  z<-cbind(ai,abi1,abi2,ari1,ari2,ari3)
  Z<-kronecker(diag(n),z)

prob_mis<-array(0,dim=c(n*nm*nt*nL,3,M)) 
orgin<-array(0,dim=c(n*nm*nt*nL,3,M))
colnames(orgin)<-c("y","x7","x6")
mis_number<-matrix(0,nrow=2,ncol=M) 

# parameters for the x7 model 
bi.x_record<-array(0,dim=c(2*n,5,M))
beta.x_record<-array(0,dim=c(length(beta.x),5,M))
sigma.x_record<-array(0,dim=c(3,5,M))
x7_record<-array(0,dim=c(n*nm*nt*nL,5,M))

# parameters for the y model 
bi_record<-array(0,dim=c(ncol(z)*n,5,M))
beta_record<-array(0,dim=c(length(beta.true),5,M))
sigma_record<-array(0,dim=c(4,5,M))
y_record<-array(0,dim=c(n*nm*nt*nL,5,M))

mis_Y<-mis_x7<-matrix(0,nrow=M,ncol=n*nm*nt*nL)

 ind=rep(1:n,each=(nm*nt*nL))
 method<-rep(1:nm,each=nt*nL,times=n)-1
 time<-rep(rep(1:nt,each=nL),times=(n*nm))
 repl<-rep(1:(nm*nt*nL),n)
 outlier.y.num<-matrix(0,M,nout*nm*nt*nL)
 out.y<-matrix(0,M,nout)

for (r in (1:M)){
  xy_data<-as.data.frame(alldata[,,r])            
  x6<-xy_data$x6
  prob_mis[,1,r]<-x6
  orgin[,3,r]<-x6
  y<-xy_data$y      
  out.y[r,]=sort(rev(order(apply(matrix(y,nrow=n,ncol=nm*nt*nL,byrow=T),1,mean)))[1:nout])
  outlier.y.num[r,]<-c(((out.y[r,1]-1)*nm*nt*nL+1):(out.y[r,1]*nm*nt*nL),((out.y[r,2]-1)*nm*nt*nL+1):(out.y[r,2]*nm*nt*nL))

  orgin[,1,r]<-y
  mis_Y[r,]<-y         
  x7<-xy_data$x7    
  orgin[,2,r]<-x7
  mis_x7[r,]<-x7      
    
#Creating missing values
 for(i in (1:(n*nm*nt*nL))){
    ey<-exp(b1+b2*x6[i]+b3*method[i])
    ex<-exp(b4+b5*x6[i]+b6*y[i])
    p_y<-ey/(1+ey)
    p_x<-ex/(1+ex)
    prob_mis[i,2,r]<-p_y
    prob_mis[i,3,r]<-p_x
    my<-rbinom(1,1,prob=p_y)
    mx<-rbinom(1,1,prob=p_x)
    if(my==1&i%in%c(1:(n*nm*nt*nL))[-outlier.y.num[r,]]){
      mis_Y[r,i]<-NA
    }
    if(my==0&mx==1&i%in%c(1:(n*nm*nt*nL))[-outlier.y.num[r,]]){
      mis_x7[r,i]<-NA
    }
  }
}

alldatanew=alldata

for (r in (1:M)){
  y.old<-alldatanew[,1,r]           
  y<-y.old
  y[outlier.y.num[r,1:(1*nm*nt*nL)]]<-y.old[outlier.y.num[r,1:(1*nm*nt*nL)]]+
                                      1*(alldata[outlier.y.num[r,1:(1*nm*nt*nL)],2,r]+2)+
                                      rep(rnorm(1,0,2^0.5),each=nm*nt*nL)
  y[outlier.y.num[r,((1*nm*nt*nL)+1):(nout*nm*nt*nL)]]<-y.old[outlier.y.num[r,((1*nm*nt*nL)+1):(nout*nm*nt*nL)]]+
                                                        1*(alldata[outlier.y.num[r,((1*nm*nt*nL)+1):(nout*nm*nt*nL)],2,r]+2) 
  alldatanew[,1,r]<-y
 }

like.H0=like.H00=rep(0,M)
like.H1=matrix(0,nrow=n,ncol=M)
LRT.oringal=matrix(0,nrow=n,ncol=M)

like.h0=matrix(0,nrow=Bnum,ncol=M)
like.h1=array(0,dim=c(n,Bnum,M))
LRT.boots=array(0,dim=c(n,Bnum,M))
quant.LRT=matrix(0,nrow=n,ncol=M)

for (r in (1:M)){
  mis_number[1,r]<-length(which(is.na(mis_Y[r,])))
  mis_number[2,r]<-length(which(is.na(mis_x7[r,])))
  misY_obs<-which(is.na(mis_Y[r,]))
  misX_obs<-which(is.na(mis_x7[r,]))
  misXY_obs<-sort(union(misY_obs,misX_obs))
  mis_personY<-unique(ceiling(misY_obs/(nm*nt*nL)))
  mis_personX<-unique(ceiling(misX_obs/(nm*nt*nL)))

  xy_data<-as.data.frame(alldatanew[,,r])            
  y<-xy_data$y    
  x6<-xy_data$x6  
  x7<-xy_data$x7 
  
  com_data<-as.data.frame(cbind(y,ind,method,time,x6,x7,repl))
  colnames(com_data)<-c("y","ind","method","time","x6","x7","rep")
  com_data$y<-as.numeric(com_data$y)
  com_data$ind<-as.factor(com_data$ind)
  com_data$method<-as.factor(com_data$method)
  com_data$time<-as.factor(com_data$time)
  com_data$x6<-as.numeric(com_data$x6)
  com_data$x7<-as.numeric(com_data$x7)

  obs_data<-com_data[-misXY_obs,]
  colnames(obs_data)<-c("y","ind","method","time","x6","x7","rep")
  obs_data$y<-as.numeric(obs_data$y)
  obs_data$ind<-as.factor(obs_data$ind)
  obs_data$method<-as.factor(obs_data$method)
  obs_data$time<-as.factor(obs_data$time)
  obs_data$x6<-as.numeric(obs_data$x6)
  obs_data$x7<-as.numeric(obs_data$x7)
  
  form=y~method+time+method*time+x6+x7
tryCatch({model_obsXY<-lme(form,data=obs_data,random=list(ind=pdBlocked(list(~1,pdIdent(form=~-1+method),pdIdent(form=~-1+time)))),method="ML")}, error=function(e){})  
    
  X.com<-cbind(x0,x1,x2,x3,com_data$x6,com_data$x7,x4,x5)
  X0.obs<-cbind(x0,x1,x2,x3,com_data$x6,com_data$x7,x4,x5)[-misXY_obs,]

if(length(model_obsXY)!=0&is.character(model_obsXY$apVar)==FALSE){  
  vc.hat<-exp(2*attr(model_obsXY$apVar,'Pars')) 
  sa.hat<-vc.hat[1]
  sab.hat<-vc.hat[2]
  sag.hat<-vc.hat[3]
  se.hat<-model_obsXY$sigma^2
  beta.hat<-summary(model_obsXY)$tTable[,1]

D.hat<-diag(c(sa.hat,rep(sab.hat,nm),rep(sag.hat,nt)))
V0.hat<-diag(1,n*nm*nt*nL)+Z%*%kronecker(diag(n),D.hat)%*%t(Z)/se.hat
V0.hat.obs<-V0.hat[-misXY_obs,-misXY_obs]
V0.hat.obs.inv<-solve(V0.hat.obs)
P0.hat.obs<-V0.hat.obs.inv-V0.hat.obs.inv%*%X0.obs%*%solve(t(X0.obs)%*%V0.hat.obs.inv%*%X0.obs)%*%t(X0.obs)%*%V0.hat.obs.inv
like.H0[r]<-summary(model_obsXY)$logLik 
like.H00[r]<--0.5*(log(det(V0.hat.obs*se.hat))+n*log(t(model_obsXY$r[,1])%*%V0.hat.obs.inv%*%model_obsXY$r[,1]/se.hat))
}

n1=n*nm*nt*nL-length(misXY_obs)
xi<-ws<-phis<-matrix(0,nrow=n1,ncol=n)
logphis<-logws<-rep(0,n)

  for (i in 1:n){
  d=rep(0,n*nm*nt*nL)
  d[(1+(i-1)*nm*nt*nL):(i*nm*nt*nL)]=1
  dmis=d[-misXY_obs]

   y<-xy_data$y    
   x6<-xy_data$x6
   x7<-xy_data$x7    
  
  ymis_data<-cbind(com_data,d)[-misXY_obs,]
  colnames(ymis_data)<-c("y","ind","method","time","x6","x7","rep","d")
  ymis_data$y<-as.numeric(ymis_data$y)
  ymis_data$ind<-as.factor(ymis_data$ind)
  ymis_data$method<-as.factor(ymis_data$method)
  ymis_data$time<-as.factor(ymis_data$time)
  ymis_data$x6<-as.numeric(ymis_data$x6)
  ymis_data$x7<-as.numeric(ymis_data$x7)

X1.obs<-cbind(x0,x1,x2,x3,com_data$x6,com_data$x7,d,x4,x5)[-misXY_obs,]

cii=as.vector(t(dmis)%*%P0.hat.obs%*%dmis)
ei=as.vector(t(dmis)%*%P0.hat.obs%*%ymis_data$y)
ti2=as.vector(ei^2/(cii*se.hat))

se.hat.y=ifelse(ti2>1,(n1-ncol(X1.obs)-ti2)/(n1-ncol(X1.obs)-1)*se.hat,se.hat)
sd.hat.y=ifelse(ti2>1,(n1-ncol(X1.obs))*(ti2-1)/(cii*(n1-ncol(X1.obs)-ti2)),0)

if(length(model_obsXY)!=0&is.character(model_obsXY$apVar)==FALSE){
V1.hat.obs<-V0.hat.obs+dmis%*%t(dmis)*sd.hat.y
V.tuda.obs=solve(t(chol(V0.hat.obs)))%*%V1.hat.obs%*%solve(chol(V0.hat.obs))

X1.tuda.obs<-solve(t(chol(V0.hat.obs)))%*%X1.obs
WWt=diag(1,n*nm*nt*nL)[-misXY_obs,-misXY_obs]-X1.tuda.obs%*%solve(t(X1.tuda.obs)%*%X1.tuda.obs)%*%t(X1.tuda.obs)
tryCatch({W=svd(WWt,nu=n*nm*nt*nL-ncol(X1.tuda.obs),nv=n*nm*nt*nL-ncol(X1.tuda.obs))$u},error=function(e){})

xi[,i]=eigen(t(W)%*%solve(t(chol(V0.hat.obs)))%*%dmis%*%t(dmis)%*%solve(chol(V0.hat.obs))%*%W,symmetric=T)$values*sd.hat.y

D.hat.y<-diag(c(sa.hat,rep(sab.hat,nm),rep(sag.hat,nt)))

WxWxt=diag(1,n*nm*nt*nL)[-misXY_obs,-misXY_obs]-X1.obs%*%solve(t(X1.obs)%*%X1.obs)%*%t(X1.obs)
tryCatch({Wx=svd(WxWxt,nu=n*nm*nt*nL-ncol(X1.obs),nv=n*nm*nt*nL-ncol(X1.obs))$u},error=function(e){})
phis[,i]=eigen(t(Wx)%*%solve(t(chol(V0.hat.obs)))%*%dmis%*%t(dmis)%*%solve(chol(V0.hat.obs))%*%Wx,symmetric=T)$values*
         mean(c(sa.hat,sab.hat,sag.hat)/se.hat.y)
logphis[i]=log(det(diag(1+phis[,i])))

V1.hat.obs.inv=solve(V1.hat.obs)
beta.hat.y=solve(t(X1.obs)%*%V1.hat.obs.inv%*%X1.obs)%*%t(X1.obs)%*%V1.hat.obs.inv%*%ymis_data$y
res.y=ymis_data$y-X1.obs%*%beta.hat.y
like.H1[i,r]<--0.5*(log(det(V1.hat.obs*se.hat.y))+n*log(t(res.y)%*%V1.hat.obs.inv%*%res.y/se.hat.y))
LRT.oringal[i,r]=-2*(like.H00[r]-like.H1[i,r])

for (B in 1:Bnum){
vs<-rnorm(n1-ncol(X0.obs))
us<-rnorm(n1-ncol(X1.obs))
like.h0[B,r]<--n*log(sum(vs^2))
like.h1[i,B,r]<--n*log(sum(us^2/(1+xi[1:(n1-ncol(X1.obs)),i])))-logphis[i]
LRT.boots[i,B,r]=-(like.h0[B,r]-like.h1[i,B,r]) 
}}
}
}

outlier.select<-matrix(0,nrow=n,ncol=M)
for (r in 1:M){
for (i in 1:n){
quant.LRT[i,r]=quantile(LRT.boots[i,,r],0.95)
outlier.select[i,r]=ifelse(LRT.oringal[i,r]>quant.LRT[i,r],1,0)
}}

save.image("D:\\ProposedLRT.RData")

